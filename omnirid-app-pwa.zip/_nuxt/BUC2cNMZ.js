var e=`<script setup lang="ts">
import { useTelemetry } from '~/composables/useTelemetry'

const { status } = useTelemetry()
<\/script>

<template>
  <UDashboardPanel
    id="monitor-dashboard"
    class="bg-default"
    :ui="{ root: 'pt-16', body: 'p-0 overflow-hidden' }"
  >
    <template #body>
      <DroneMap
        :status="status"
        height-class="h-[calc(100svh-4rem)]"
        class="rounded-none"
      />
    </template>
  </UDashboardPanel>
</template>
`,t=`<script setup lang="ts">
import type { PageBadgeColor } from '~/components/PageHero.vue'
import { installTargets, processSteps } from '~/config/content'
import { pageForRoute, pageStatusMeta } from '~/pages.config'

const { espIp, isEspConnected, isChecking, lastError, isWifiTransport, canOta, canFlashUsb, refresh } = useEspConnection()
const route = useRoute()

const selectedTarget = ref('esp32')
const heroBadges: { label: string, color?: PageBadgeColor }[] = [
  { label: 'Install', color: 'primary' },
  { label: 'OTA', color: 'info' }
]
const targetNames = installTargets.map(target => target.name).join(', ')
const heroStatus = computed(() => {
  const page = pageForRoute(route.path)
  return page ? pageStatusMeta(page.status) : undefined
})

const fileInput = ref<HTMLInputElement | null>(null)
const dragActive = ref(false)
const selectedFile = ref<File | null>(null)
const expectedSha = ref('')
const isHashing = ref(false)
const hashingNotice = ref('')
const uploadProgress = ref(0)
const isUploading = ref(false)
const uploadError = ref<string | null>(null)
const uploadMessage = ref<string | null>(null)

const USB_PORT_KEY = 'omnirid:usb-port'
const usbPort = ref('COM3')
const isFlashing = ref(false)
const flashProgress = ref(0)
const flashMessage = ref<string | null>(null)
const toast = useToast()
const { notifyInfo, notifyError } = useNotifications()

onMounted(() => {
  if (true) {
    usbPort.value = localStorage.getItem(USB_PORT_KEY) || 'COM3'
  }
})

const flashStatus = computed(() => {
  if (isFlashing.value) {
    if (flashProgress.value < 20) return 'Erasing flash…'
    if (flashProgress.value < 85) return 'Writing firmware…'
    if (flashProgress.value < 100) return 'Verifying…'
    return 'Finishing up…'
  }
  if (flashMessage.value) return flashMessage.value
  return canFlashUsb.value ? \`Ready to flash \${usbPort.value}\` : 'Waiting for a USB connection'
})

const flashFirmware = async () => {
  if (!canFlashUsb.value || isFlashing.value) return
  const target = installTargets.find(item => item.value === selectedTarget.value)?.name ?? 'ESP32'
  isFlashing.value = true
  flashMessage.value = null
  flashProgress.value = 0
  await new Promise<void>((resolve) => {
    const timer = setInterval(() => {
      flashProgress.value = Math.min(100, flashProgress.value + Math.round(Math.random() * 12) + 4)
      if (flashProgress.value >= 100) {
        clearInterval(timer)
        resolve()
      }
    }, 220)
  })
  isFlashing.value = false
  flashMessage.value = \`Flashed \${target} over \${usbPort.value}\`
  toast.add({
    title: \`\${target} flashed\`,
    description: \`Firmware written over \${usbPort.value} (WebSerial).\`,
    icon: 'i-lucide-check',
    color: 'success'
  })
  notifyInfo(\`\${target} flashed\`, \`Firmware written over \${usbPort.value} (WebSerial).\`)
}

const formatBytes = (bytes: number) => {
  if (bytes < 1024) return \`\${bytes} B\`
  if (bytes < 1024 ** 2) return \`\${(bytes / 1024).toFixed(1)} KB\`
  return \`\${(bytes / 1024 ** 2).toFixed(2)} MB\`
}

const rotr = (x: number, n: number) => (x >>> n) | (x << (32 - n))

const sha256HexArray = (data: Uint8Array): string => {
  const K = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
  ]
  const l = data.length
  const padLen = Math.ceil((l + 9) / 64) * 64
  const buf = new Uint8Array(padLen)
  buf.set(data)
  buf[l] = 0x80
  const view = new DataView(buf.buffer)
  view.setUint32(padLen - 8, Math.floor(l / 0x100000000))
  view.setUint32(padLen - 4, (l * 8) >>> 0)
  const H = new Uint32Array([0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19])
  const w = new Uint32Array(64)
  for (let off = 0; off < padLen; off += 64) {
    for (let i = 0; i < 16; i++) w[i] = view.getUint32(off + i * 4)
    for (let i = 16; i < 64; i++) {
      const s0 = rotr(w[i - 15]!, 7) ^ rotr(w[i - 15]!, 18) ^ (w[i - 15]! >>> 3)
      const s1 = rotr(w[i - 2]!, 17) ^ rotr(w[i - 2]!, 19) ^ (w[i - 2]! >>> 10)
      w[i] = (w[i - 16]! + s0 + w[i - 7]! + s1) >>> 0
    }
    let a = H[0]!
    let b = H[1]!
    let c = H[2]!
    let d = H[3]!
    let e = H[4]!
    let f = H[5]!
    let g = H[6]!
    let h = H[7]!
    for (let i = 0; i < 64; i++) {
      const S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25)
      const ch = (e & f) ^ (~e & g)
      const t1 = (h + S1 + ch + (K[i] ?? 0) + (w[i] ?? 0)) >>> 0
      const S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22)
      const maj = (a & b) ^ (a & c) ^ (b & c)
      const t2 = (S0 + maj) >>> 0
      h = g
      g = f
      f = e
      e = (d + t1) >>> 0
      d = c
      c = b
      b = a
      a = (t1 + t2) >>> 0
    }
    H[0] = (H[0]! + a) >>> 0
    H[1] = (H[1]! + b) >>> 0
    H[2] = (H[2]! + c) >>> 0
    H[3] = (H[3]! + d) >>> 0
    H[4] = (H[4]! + e) >>> 0
    H[5] = (H[5]! + f) >>> 0
    H[6] = (H[6]! + g) >>> 0
    H[7] = (H[7]! + h) >>> 0
  }
  return Array.from(H, value => value.toString(16).padStart(2, '0')).join('')
}

const computeSha256 = async (file: File): Promise<string> => {
  const buf = await file.arrayBuffer()
  if (typeof globalThis.crypto?.subtle?.digest === 'function') {
    const digest = await crypto.subtle.digest('SHA-256', buf)
    return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, '0')).join('')
  }
  return sha256HexArray(new Uint8Array(buf))
}

const pickFile = (file: File | null) => {
  if (!file) return
  selectedFile.value = file
  expectedSha.value = ''
  uploadProgress.value = 0
  uploadError.value = null
  uploadMessage.value = null
  isHashing.value = true
  hashingNotice.value = ''
  computeSha256(file)
    .then((hash) => {
      expectedSha.value = hash
    })
    .catch(() => {
      hashingNotice.value = 'Could not hash the selected file'
      notifyError('Firmware hashing failed', \`Could not compute SHA-256 for \${file.name}.\`)
      toast.add({
        title: 'Firmware hashing failed',
        description: \`Could not compute SHA-256 for \${file.name}.\`,
        icon: 'i-lucide-circle-alert',
        color: 'error'
      })
    })
    .finally(() => {
      isHashing.value = false
    })
}

const onFileChange = (event: Event) => {
  const input = event.target as HTMLInputElement
  pickFile(input.files?.[0] ?? null)
}

const onDrop = (event: DragEvent) => {
  dragActive.value = false
  pickFile(event.dataTransfer?.files?.[0] ?? null)
}

const clearFile = () => {
  selectedFile.value = null
  expectedSha.value = ''
  isHashing.value = false
  hashingNotice.value = ''
  uploadProgress.value = 0
  uploadError.value = null
  uploadMessage.value = null
  if (fileInput.value) fileInput.value.value = ''
}

const readOtaError = (text: string): string | null => {
  if (!text) return null
  try {
    const parsed = JSON.parse(text) as Record<string, unknown>
    const error = String(parsed.error ?? '')
    const detail = String(parsed.detail ?? '')
    return [error, detail].filter(Boolean).join(': ')
  } catch {
    return text.slice(0, 240)
  }
}

const startUpload = () => {
  const file = selectedFile.value
  if (!file || !expectedSha.value || isUploading.value) return
  uploadError.value = null
  uploadMessage.value = null
  uploadProgress.value = 0
  isUploading.value = true

  const xhr = new XMLHttpRequest()
  xhr.open('POST', '/api/esp/ota')
  xhr.setRequestHeader('x-esp-ip', espIp.value)
  xhr.setRequestHeader('X-Expected-SHA256', expectedSha.value)
  xhr.setRequestHeader('Content-Type', 'application/octet-stream')
  xhr.setRequestHeader('x-esp-timeout', '300000')
  xhr.upload.onprogress = (event) => {
    if (event.lengthComputable) {
      uploadProgress.value = Math.round((event.loaded / event.total) * 100)
    }
  }
  xhr.onload = () => {
    isUploading.value = false
    if (xhr.status >= 200 && xhr.status < 300) {
      uploadMessage.value = 'Upload complete. The device is rebooting into the new firmware.'
      isEspConnected.value = false
      notifyInfo('Firmware uploaded', 'The device is rebooting into the new firmware.')
      toast.add({
        title: 'Firmware uploaded',
        description: 'The device is rebooting into the new firmware.',
        icon: 'i-lucide-check',
        color: 'success'
      })
    } else {
      uploadError.value = readOtaError(xhr.responseText) ?? \`Upload failed (HTTP \${xhr.status}).\`
      notifyError('Firmware upload failed', uploadError.value)
      toast.add({
        title: 'Firmware upload failed',
        description: uploadError.value,
        icon: 'i-lucide-circle-alert',
        color: 'error'
      })
    }
  }
  xhr.onerror = () => {
    isUploading.value = false
    uploadError.value = 'Upload failed — the device became unreachable. Keep it powered and retry.'
    notifyError('Firmware upload failed', uploadError.value)
    toast.add({
      title: 'Firmware upload failed',
      description: uploadError.value,
      icon: 'i-lucide-circle-alert',
      color: 'error'
    })
  }
  xhr.onabort = () => {
    isUploading.value = false
  }
  xhr.send(file)
}
<\/script>

<template>
  <UDashboardPanel id="firmware" class="bg-default" :ui="{ root: 'pt-16' }">
    <template #body>
      <div class="mx-auto w-full max-w-[1400px] space-y-6 px-4 pb-16 sm:px-6 lg:px-10">
        <PageHero
          title="Firmware & OTA updates"
          description="Flash over USB with WebSerial, or push an update to the connected device over WiFi with built-in SHA-256 verification."
          :badges="heroBadges"
          :status="heroStatus"
          size="sm"
        >
          <template #right>
            <UButton
              to="/"
              color="neutral"
              variant="outline"
              size="lg"
              icon="i-lucide-arrow-left"
              label="Back to home"
            />
          </template>
        </PageHero>

        <section class="grid gap-6 lg:grid-cols-2">
          <ContentSection
            title="Install via USB"
            description="First flash or recovery using WebSerial, straight from the browser."
            icon="i-lucide-usb"
            heading="md"
          >
            <div class="space-y-4">
              <div class="flex flex-wrap gap-2">
                <UButton
                  v-for="target in installTargets"
                  :key="target.value"
                  :color="selectedTarget === target.value ? 'primary' : 'neutral'"
                  :variant="selectedTarget === target.value ? 'solid' : 'soft'"
                  :label="target.name"
                  @click="selectedTarget = target.value"
                />
                <UButton
                  color="neutral"
                  variant="ghost"
                  icon="i-lucide-clock"
                  label="Future devices"
                  disabled
                />
              </div>

              <div class="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-default bg-elevated/40 p-4">
                <div class="flex items-center gap-3">
                  <span class="relative flex size-2.5">
                    <span v-if="canFlashUsb" class="absolute inline-flex size-full animate-ping rounded-full bg-emerald-500 opacity-60" />
                    <span class="relative inline-flex size-2.5 rounded-full" :class="canFlashUsb ? 'bg-emerald-500' : isWifiTransport ? 'bg-sky-500' : 'bg-red-500'" />
                  </span>
                  <div>
                    <p class="text-sm font-medium text-highlighted">
                      {{ canFlashUsb ? 'USB ready' : isWifiTransport ? 'Connected over WiFi' : 'USB not connected' }}
                    </p>
                    <p class="truncate text-xs text-muted">
                      {{ canFlashUsb ? \`\${usbPort} · WebSerial\` : 'Serial flashing needs a USB connection.' }}
                    </p>
                  </div>
                </div>
                <UButton
                  size="sm"
                  color="neutral"
                  variant="outline"
                  icon="i-lucide-refresh-cw"
                  label="Re-check"
                  :loading="isChecking"
                  @click="refresh()"
                />
              </div>

              <div class="relative overflow-hidden rounded-lg border border-default bg-elevated/40 p-5">
                <div
                  v-if="isFlashing"
                  class="pointer-events-none absolute inset-0 bg-gradient-to-r from-transparent via-primary/10 to-transparent motion-safe:animate-pulse"
                />
                <div class="relative flex items-center gap-4">
                  <div class="relative flex size-12 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary ring-1 ring-primary/20">
                    <UIcon
                      name="i-lucide-cpu"
                      class="size-6"
                      :class="isFlashing ? 'animate-pulse' : ''"
                      aria-hidden="true"
                    />
                  </div>
                  <div class="min-w-0 flex-1">
                    <p class="text-sm font-medium text-highlighted">
                      {{ flashStatus }}
                    </p>
                    <div class="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-accented">
                      <div class="h-full rounded-full bg-primary transition-all duration-300" :style="{ width: \`\${flashProgress}%\` }" />
                    </div>
                    <p class="mt-1 font-mono text-[11px] tabular-nums text-muted">
                      {{ flashProgress }}%
                    </p>
                  </div>
                </div>
              </div>

              <UAlert
                v-if="!canFlashUsb"
                color="info"
                icon="i-lucide-usb"
                title="USB connection required"
              >
                Serial flashing and recovery use a direct USB connection. Switch the connection to USB on the board to flash over serial.
              </UAlert>

              <UButton
                color="primary"
                size="lg"
                class="w-full"
                icon="i-lucide-plug-zap"
                :label="isFlashing ? 'Flashing…' : 'Flash firmware'"
                :disabled="!canFlashUsb || isFlashing"
                :loading="isFlashing"
                @click="flashFirmware"
              />
            </div>
          </ContentSection>

          <ContentSection
            title="Update over WiFi (OTA)"
            description="Push a new .bin to the connected device — no USB needed."
            icon="i-lucide-cloud-upload"
            icon-class="bg-emerald-500/10 text-emerald-500 ring-emerald-500/20"
            heading="md"
          >
            <div class="space-y-4">
              <div class="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-default bg-elevated/40 p-4">
                <div class="flex items-center gap-3">
                  <span class="relative flex size-2.5">
                    <span v-if="isEspConnected" class="absolute inline-flex size-full animate-ping rounded-full bg-emerald-500 opacity-60" />
                    <span class="relative inline-flex size-2.5 rounded-full" :class="isEspConnected ? 'bg-emerald-500' : isChecking ? 'bg-amber-500' : 'bg-red-500'" />
                  </span>
                  <div>
                    <p class="text-sm font-medium text-highlighted">
                      {{ isEspConnected ? 'Device connected' : isChecking ? 'Checking connection…' : 'Device offline' }}
                    </p>
                    <p class="truncate text-xs text-muted" :title="espIp">
                      {{ espIp }}
                    </p>
                  </div>
                </div>
                <UButton
                  size="sm"
                  color="neutral"
                  variant="outline"
                  icon="i-lucide-refresh-cw"
                  label="Re-check"
                  :loading="isChecking"
                  @click="refresh()"
                />
              </div>

              <UAlert
                v-if="!isEspConnected"
                color="warning"
                icon="i-lucide-wifi-off"
                title="Connect first"
              >
                The update is sent straight to the device. Make sure it is powered, reachable at <code class="break-all">{{ espIp }}</code>, and your computer is connected to its WiFi network.
              </UAlert>
              <UAlert
                v-else-if="!canOta"
                color="info"
                icon="i-lucide-usb"
                title="WiFi required for OTA"
              >
                You are connected over USB. OTA updates are sent over WiFi — switch the connection to WiFi to push firmware over the air, or use serial flashing below.
              </UAlert>
              <UAlert
                v-else-if="lastError"
                color="error"
                icon="i-lucide-alert-circle"
                title="Connection problem"
                :description="lastError"
              />

              <p v-if="!canOta" class="text-sm leading-6 text-muted">
                OTA updates are delivered over WiFi. Connect to the device's WiFi network, then pick a <code>.bin</code> firmware built for your target ({{ targetNames }}). This page hashes the file (SHA-256) and uploads it to the device <code>/ota</code> endpoint.
              </p>

              <template v-else>
                <div
                  role="button"
                  tabindex="0"
                  class="flex cursor-pointer flex-col items-center justify-center gap-3 rounded-lg border-2 border-dashed border-default bg-elevated/40 px-4 py-8 text-center transition hover:border-primary/40 hover:bg-primary/5 focus-visible:outline-primary/40"
                  :class="dragActive && 'border-primary/60 bg-primary/5'"
                  @click="fileInput?.click()"
                  @keydown.enter="fileInput?.click()"
                  @dragover.prevent="dragActive = true"
                  @dragleave.prevent="dragActive = false"
                  @drop.prevent="onDrop"
                >
                  <div class="flex size-10 items-center justify-center rounded-lg bg-primary/10 text-primary ring-1 ring-primary/20">
                    <UIcon name="i-lucide-file-up" class="size-5" />
                  </div>
                  <div>
                    <p class="text-sm font-medium text-highlighted">
                      Drop a firmware <code>.bin</code> file or click to browse
                    </p>
                    <p class="mt-1 text-xs text-muted">
                      Must be built for {{ targetNames }}. Anything else is rejected by the device.
                    </p>
                  </div>
                  <input
                    ref="fileInput"
                    type="file"
                    accept=".bin,application/octet-stream"
                    class="hidden"
                    @change="onFileChange"
                  >
                </div>

                <div v-if="selectedFile" class="rounded-lg border border-default bg-elevated/40 p-4">
                  <div class="flex items-start justify-between gap-3">
                    <div class="min-w-0">
                      <p class="truncate text-sm font-semibold text-highlighted" :title="selectedFile.name">
                        {{ selectedFile.name }}
                      </p>
                      <p class="mt-1 text-xs text-muted">
                        {{ formatBytes(selectedFile.size) }}
                      </p>
                      <p class="mt-2 text-[11px] text-muted">
                        <span v-if="isHashing">Computing SHA-256…</span>
                        <span v-else-if="expectedSha" class="font-mono" :title="\`Full SHA-256: \${expectedSha}\`">SHA-256 {{ expectedSha.slice(0, 12) }}…</span>
                        <span v-else-if="hashingNotice" class="text-red-500">{{ hashingNotice }}</span>
                        <span v-else class="text-red-500">SHA-256 unavailable</span>
                      </p>
                    </div>
                    <UButton
                      size="sm"
                      color="neutral"
                      variant="outline"
                      icon="i-lucide-x"
                      aria-label="Remove file"
                      :disabled="isUploading"
                      @click="clearFile"
                    />
                  </div>
                  <UProgress
                    v-if="isUploading || uploadMessage"
                    :value="uploadProgress"
                    size="sm"
                    color="primary"
                    class="mt-3"
                  />
                  <p v-if="isUploading" class="mt-2 text-xs text-muted">
                    Uploading — keep the device powered… {{ uploadProgress }}%
                  </p>
                </div>

                <UAlert
                  v-if="uploadError"
                  color="error"
                  icon="i-lucide-alert-circle"
                  title="Upload failed"
                  :description="uploadError"
                />
                <UAlert
                  v-else-if="uploadMessage"
                  color="success"
                  icon="i-lucide-circle-check"
                  title="Update applied"
                  :description="uploadMessage"
                />

                <UAlert color="warning" icon="i-lucide-shield-alert" title="Locked devices (lock level 1+)">
                  The server also requires a valid Ed25519 signature (<code>X-Signature</code>) when the device is locked. This page cannot sign uploads for locked devices — flash those via USB instead.
                </UAlert>

                <UButton
                  color="primary"
                  size="lg"
                  class="w-full"
                  icon="i-lucide-upload"
                  :label="isUploading ? 'Uploading…' : 'Upload firmware'"
                  :disabled="!expectedSha || isUploading"
                  @click="startUpload"
                />

                <p class="text-xs leading-5 text-muted">
                  A 1 MB image takes roughly 30 seconds. The device verifies the SHA-256 hash (and the signature when locked), writes to the <code>ota_0</code> partition and reboots automatically. A failed update rolls back to the factory firmware; you can always recover via USB.
                </p>
              </template>
            </div>
          </ContentSection>
        </section>

        <ContentSection title="Firmware installation flow" description="From first flash to a verified over-the-air update.">
          <div class="grid gap-px overflow-hidden rounded-lg border border-default bg-accented sm:grid-cols-2 xl:grid-cols-4">
            <div
              v-for="(step, index) in processSteps"
              :key="step.name"
              class="flex flex-col gap-3 bg-default p-4 sm:p-5"
            >
              <div class="flex items-center gap-2.5">
                <span class="label-data">0{{ index + 1 }}</span>
                <span class="flex size-8 items-center justify-center rounded-sm bg-primary/10 text-primary ring-1 ring-primary/15">
                  <UIcon :name="step.icon" class="size-4" />
                </span>
              </div>
              <h3 class="text-display text-base text-highlighted">
                {{ step.name }}
              </h3>
              <p class="text-sm leading-6 text-muted">
                {{ step.detail }}
              </p>
            </div>
          </div>
        </ContentSection>
      </div>
    </template>
  </UDashboardPanel>
</template>
`,n=`<script setup lang="ts">
import type { PageBadgeColor } from '~/components/PageHero.vue'
import type { GuideSection } from '~/config/guide'
import GuideBlocks from '~/components/docs/GuideBlocks.vue'
import { guideSections, sectionSearchText } from '~/config/guide'
import { pageForRoute, pageStatusMeta } from '~/pages.config'

const heroBadges: { label: string, color?: PageBadgeColor }[] = [{ label: 'In-app Guide', color: 'primary' }]
const route = useRoute()
const heroStatus = computed(() => {
  const page = pageForRoute(route.path)
  return page ? pageStatusMeta(page.status) : undefined
})

const openSections = ref<string[]>([guideSections[0]?.id ?? ''])
const query = ref('')
const allOpen = ref(false)

const sectionIndex = guideSections.map(section => ({
  id: section.id,
  haystack: \`\${section.number} \${section.title} \${sectionSearchText(section)}\`.toLowerCase()
}))

function sectionPreview(section: GuideSection): string {
  const raw = section.intro?.trim() ? section.intro : sectionSearchText(section)
  const clean = raw.replace(/\\s+/g, ' ').trim()
  return clean.length > 170 ? \`\${clean.slice(0, 170)}…\` : clean
}

const visibleItems = computed(() => {
  const terms = query.value.toLowerCase().split(/\\s+/).filter(Boolean)
  return guideSections
    .filter((section) => {
      if (!terms.length) return true
      const haystack = sectionIndex.find(entry => entry.id === section.id)?.haystack ?? ''
      return terms.every(term => haystack.includes(term))
    })
    .map(section => ({
      label: \`\${section.number}. \${section.title}\`,
      value: section.id,
      number: section.number,
      icon: section.icon,
      preview: sectionPreview(section)
    }))
})

function sectionById(id: string) {
  return guideSections.find(s => s.id === id)!
}

function setAll(expand: boolean) {
  openSections.value = expand ? guideSections.map(s => s.id) : []
  allOpen.value = expand
}

function onOpenChange(value: string | string[] | undefined) {
  openSections.value = Array.isArray(value) ? value : (value ? [value] : [])
}

function scrollToSection(id: string) {
  if (!true) return
  if (!guideSections.some(s => s.id === id)) return
  query.value = ''
  const scroll = () => {
    requestAnimationFrame(() => {
      document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' })
    })
  }
  if (!openSections.value.includes(id)) {
    openSections.value.push(id)
    nextTick(scroll)
  } else {
    scroll()
  }
}

function scrollToHash(href: string) {
  scrollToSection(href.replace('#guide-', ''))
}

watch(() => route.hash, (hash) => {
  if (!hash) return
  scrollToSection(decodeURIComponent(hash.slice(1)))
}, { immediate: true })

function onBodyClick(event: MouseEvent) {
  const anchor = (event.target as HTMLElement).closest('a[href^="#guide-"]') as HTMLAnchorElement | null
  if (!anchor) return
  event.preventDefault()
  scrollToHash(anchor.getAttribute('href')!)
}
<\/script>

<template>
  <UDashboardPanel id="guide" class="bg-default" :ui="{ root: 'pt-16' }">
    <template #body>
      <div class="mx-auto w-full max-w-[1400px] space-y-6 px-4 pb-16 sm:px-6 lg:px-10">
        <SectionTabs group="guide" class="mb-2" />
        <PageHero
          title="OmniRID technical guide"
          description="A practical reference for installation, configuration, protocols, OTA, security and regulatory information for the OmniRID ESP32 Remote ID platform."
          :badges="heroBadges"
          :status="heroStatus"
        >
          <template #right>
            <UButton
              to="/"
              color="neutral"
              variant="outline"
              icon="i-lucide-arrow-left"
              label="Back to home"
            />
          </template>
        </PageHero>

        <div class="flex flex-col gap-3 rounded-lg border border-default bg-elevated/40 p-3 sm:flex-row sm:items-center sm:justify-between">
          <USearchInput
            v-model="query"
            placeholder="Search sections..."
            class="w-full sm:max-w-sm"
          />
          <div class="flex items-center justify-between gap-2 sm:justify-end">
            <UBadge
              color="neutral"
              variant="soft"
              size="sm"
              :label="\`\${visibleItems.length} sections\`"
            />
            <UButtonGroup size="sm">
              <UButton
                color="neutral"
                variant="outline"
                icon="i-lucide-chevrons-down-up"
                label="Expand all"
                :disabled="allOpen"
                @click="setAll(true)"
              />
              <UButton
                color="neutral"
                variant="outline"
                icon="i-lucide-chevrons-up-down"
                label="Collapse all"
                :disabled="!allOpen"
                @click="setAll(false)"
              />
            </UButtonGroup>
          </div>
        </div>

        <div data-guide-body @click="onBodyClick">
          <UAccordion
            :items="visibleItems"
            :model-value="openSections"
            type="multiple"
            collapsible
            :unmount-on-hide="false"
            class="space-y-2"
            :ui="{
              item: 'overflow-hidden rounded-lg border border-default bg-elevated/40 transition-colors duration-200 hover:border-primary/25',
              header: 'group transition-colors',
              trigger: 'w-full gap-3 px-4 py-3.5 sm:px-5',
              content: '',
              body: ''
            }"
            @update:model-value="onOpenChange"
          >
            <template #leading="{ item, open: itemOpen }">
              <span
                class="flex size-8 shrink-0 items-center justify-center rounded-sm ring-1 transition-colors duration-200"
                :class="itemOpen ? 'bg-primary/15 text-primary ring-primary/30' : 'bg-default text-muted ring-default hover:bg-elevated'"
              >
                <UIcon :name="item.icon" class="size-4" />
              </span>
            </template>
            <template #default="{ item, open: itemOpen }">
              <span class="flex min-w-0 items-center gap-2.5">
                <UBadge
                  color="neutral"
                  variant="soft"
                  size="sm"
                  class="shrink-0 justify-center font-mono"
                  :ui="{ base: 'size-6 rounded-sm' }"
                >
                  {{ item.number }}
                </UBadge>
                <span class="min-w-0">
                  <span class="block truncate text-sm font-semibold text-highlighted">{{ item.label }}</span>
                  <span v-if="!itemOpen" class="mt-0.5 block truncate text-xs text-muted">{{ item.preview }}</span>
                </span>
              </span>
            </template>
            <template #trailing="{ open: itemOpen }">
              <span
                class="flex size-7 shrink-0 items-center justify-center rounded-full transition-colors duration-200"
                :class="itemOpen ? 'bg-primary/10 text-primary' : 'bg-default text-muted group-hover:bg-elevated group-hover:text-highlighted'"
              >
                <UIcon name="i-lucide-chevron-down" class="size-4 transition-transform duration-300" :class="itemOpen && 'rotate-180'" />
              </span>
            </template>
            <template #body="{ item, open: itemOpen }">
              <div :id="item.value" class="scroll-mt-28">
                <div :class="!itemOpen ? 'hidden' : ''">
                  <div class="border-t border-default px-4 py-5 sm:px-5">
                    <GuideBlocks :section="sectionById(item.value)" />
                  </div>
                </div>
              </div>
            </template>
          </UAccordion>
        </div>
      </div>
    </template>
  </UDashboardPanel>
</template>

<style scoped>
[data-guide-body] :deep(code) {
  border-radius: 0.375rem;
  padding: 0.125rem 0.35rem;
  font-size: 0.8em;
  font-weight: 500;
  background: color-mix(in srgb, var(--ui-primary) 10%, transparent);
  color: var(--ui-text);
}

[data-guide-body] :deep(a) {
  color: var(--ui-primary);
  font-weight: 500;
  text-decoration: underline;
  text-underline-offset: 2px;
}

[data-guide-body] :deep(pre code) {
  background: transparent;
  padding: 0;
  font-weight: 400;
}
</style>
`,r=`<script setup lang="ts">
import { appName, appTagline, appVersion } from '~/config/app'

// Partner logos come with their own intended background: ArduPilot is light on
// dark, Betaflight/INAV are dark on light. Each logo gets a fixed tile so it
// stays legible in both app themes instead of inverting brand colors.
const flightControllers = [
  { name: 'ArduPilot', logo: '/images/ardupilot_logo.webp', tile: 'bg-[#101418]' },
  { name: 'Betaflight', logo: '/images/betaflight_logo.svg', tile: 'bg-white' },
  { name: 'INAV', logo: '/images/inav_logo.png', tile: 'bg-white' }
]

const channels = [
  { name: 'WiFi Beacon', detail: '2.4 GHz', icon: 'i-lucide-wifi' },
  { name: 'WiFi NAN', detail: '2.4 / 5 GHz', icon: 'i-lucide-signal' },
  { name: 'Bluetooth', detail: 'BLE 4.0 / 5.0', icon: 'i-lucide-bluetooth' }
]

const inputs = ['MAVLink', 'MSP', 'NMEA', 'DroneCAN']

const capabilities = [
  {
    icon: 'i-lucide-cable',
    title: 'Reads any flight controller',
    text: 'MAVLink, MSP, NMEA and DroneCAN over a single serial link, auto-detected.'
  },
  {
    icon: 'i-lucide-radio',
    title: 'Broadcasts Remote ID',
    text: 'ASTM F3411-22a Open DroneID over WiFi Beacon, WiFi NAN and BLE.'
  },
  {
    icon: 'i-lucide-shield-check',
    title: 'Signed and auditable',
    text: 'Ed25519 OTA verification, lock levels and full config persistence.'
  }
]
<\/script>

<template>
  <UDashboardPanel id="home" class="bg-default" :ui="{ root: 'pt-16' }">
    <template #body>
      <div class="pb-16">
        <!-- Masthead -->
        <section
          class="relative isolate overflow-hidden border-b border-default"
        >
          <div
            aria-hidden="true"
            class="app-grid pointer-events-none absolute inset-0 -z-10 opacity-80"
          />
          <div
            aria-hidden="true"
            class="pointer-events-none absolute -top-32 left-1/4 -z-10 h-96 w-[52rem] max-w-full [background:radial-gradient(45%_60%_at_50%_30%,var(--app-glow),transparent_72%)]"
          />

          <div
            class="mx-auto grid w-full max-w-[1400px] gap-12 px-4 py-14 sm:px-6 lg:grid-cols-[1.12fr_0.88fr] lg:items-center lg:gap-16 lg:px-10 lg:py-20"
          >
            <div class="min-w-0">
              <div class="flex flex-wrap items-center gap-3">
                <img
                  src="/images/logo.svg"
                  alt="OmniRID logo"
                  class="size-10 rounded-md ring-1 ring-default dark:invert"
                >
                <span class="label-data">{{ appName }} / {{ appTagline }}</span>
                <UBadge
                  color="warning"
                  variant="soft"
                  size="sm"
                  label="Beta"
                />
              </div>

              <h1
                class="text-display mt-7 text-[2.5rem] leading-[1.02] tracking-tight text-highlighted sm:text-5xl lg:text-6xl"
              >
                OmniRID broadcast drone Remote ID from any ESP32.
              </h1>

              <p
                class="mt-6 max-w-xl text-base leading-7 text-muted sm:text-lg"
              >
                OmniRID reads your flight controller and transmits a signed ASTM
                F3411-22a Open DroneID identity over WiFi and Bluetooth.
                Firmware written in Rust.
              </p>

              <div class="mt-8 flex flex-wrap items-center gap-2">
                <UButton
                  to="/firmware"
                  color="primary"
                  size="lg"
                  icon="i-lucide-flame"
                  label="Flash firmware"
                />
                <UButton
                  to="/guide"
                  color="neutral"
                  variant="outline"
                  size="lg"
                  icon="i-lucide-book-open"
                  label="Read the guide"
                />
              </div>
            </div>

            <!-- Transmit stack -->
            <div
              class="w-full overflow-hidden rounded-lg border border-default bg-elevated/40 backdrop-blur-sm"
            >
              <div
                class="flex items-center justify-between gap-3 border-b border-default px-4 py-3"
              >
                <span class="label-data">Transmit stack</span>
                <span class="font-mono text-[11px] text-primary">ASTM F3411-22a</span>
              </div>

              <ul class="divide-y divide-default">
                <li
                  v-for="channel in channels"
                  :key="channel.name"
                  class="flex items-center justify-between gap-3 px-4 py-3.5"
                >
                  <span
                    class="flex items-center gap-3 text-sm font-medium text-highlighted"
                  >
                    <UIcon :name="channel.icon" class="size-4 text-primary" />
                    {{ channel.name }}
                  </span>
                  <span class="font-mono text-xs text-muted">{{
                    channel.detail
                  }}</span>
                </li>
              </ul>

              <div class="border-t border-default px-4 py-3.5">
                <span class="label-data">Flight-controller input</span>
                <div class="mt-2.5 flex flex-wrap gap-1.5">
                  <span
                    v-for="input in inputs"
                    :key="input"
                    class="rounded-sm border border-default px-2 py-0.5 font-mono text-[11px] text-muted"
                  >
                    {{ input }}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </section>

        <!-- Body -->
        <div
          class="mx-auto w-full max-w-[1400px] space-y-12 px-4 pt-12 sm:px-6 lg:px-10"
        >
          <section>
            <div class="mb-5 flex items-center gap-3">
              <h2 class="text-display text-lg text-highlighted">
                What it does
              </h2>
              <div class="h-px flex-1 bg-accented" aria-hidden="true" />
            </div>
            <dl
              class="grid gap-px overflow-hidden rounded-lg border border-default bg-accented sm:grid-cols-3"
            >
              <div
                v-for="item in capabilities"
                :key="item.title"
                class="bg-default p-5"
              >
                <UIcon :name="item.icon" class="size-5 text-primary" />
                <dt class="mt-4 text-sm font-semibold text-highlighted">
                  {{ item.title }}
                </dt>
                <dd class="mt-1.5 text-sm leading-6 text-muted">
                  {{ item.text }}
                </dd>
              </div>
            </dl>
          </section>

          <section>
            <div class="mb-5 flex items-center gap-3">
              <h2 class="text-display text-lg text-highlighted">
                Works out of the box with
              </h2>
              <div class="h-px flex-1 bg-accented" aria-hidden="true" />
            </div>
            <div class="flex flex-wrap items-center gap-3">
              <div
                v-for="fc in flightControllers"
                :key="fc.name"
                class="flex items-center gap-2.5 rounded-lg border border-default bg-elevated/40 px-4 py-2.5"
              >
                <span
                  class="flex size-8 shrink-0 items-center justify-center rounded-md p-1 ring-1 ring-default"
                  :class="fc.tile"
                >
                  <img
                    :src="fc.logo"
                    :alt="\`\${fc.name} logo\`"
                    class="size-full object-contain"
                  >
                </span>
                <span class="text-sm font-semibold text-highlighted">{{
                  fc.name
                }}</span>
              </div>
            </div>
          </section>

          <section
            class="flex items-start gap-3 rounded-lg border border-warning/40 bg-warning/10 p-5"
          >
            <UIcon
              name="i-lucide-triangle-alert"
              class="mt-0.5 size-5 shrink-0 text-warning"
            />
            <div>
              <p class="text-sm font-semibold text-highlighted">
                Not released until the security audit is complete
              </p>
              <p class="mt-1 text-sm leading-6 text-muted">
                This firmware has not been security tested yet. Development and
                ground testing only.
                <UButton
                  to="/tx/security"
                  color="primary"
                  variant="link"
                  size="sm"
                  icon="i-lucide-shield-check"
                  label="Review the security model."
                />
              </p>
            </div>
          </section>

          <footer
            class="flex flex-wrap items-center gap-x-3 gap-y-1 border-t border-default pt-6 font-mono text-xs text-muted"
          >
            <span>{{ appVersion }}</span>
            <span aria-hidden="true" class="text-dimmed">/</span>
            <span>Apache 2.0</span>
            <span aria-hidden="true" class="text-dimmed">/</span>
            <span>Built by VOLTEKOVER</span>
          </footer>
        </div>
      </div>
    </template>
  </UDashboardPanel>
</template>
`,i=`<script setup lang="ts">
import { pageForRoute, pageStatusMeta } from '~/pages.config'

const route = useRoute()
const page = computed(() => pageForRoute(route.path))
const heroTitle = computed(() => page.value?.label ?? 'Console')
const heroStatus = computed(() => page.value ? pageStatusMeta(page.value.status) : undefined)

const planned = [
  'Stream the RX diagnostic log and raw packet trace',
  'Send receiver commands (channel change, scan start/stop)',
  'Command history with keyboard navigation'
]
<\/script>

<template>
  <UDashboardPanel id="rx-console" class="bg-default" :ui="{ root: 'pt-16' }">
    <template #body>
      <div class="mx-auto w-full max-w-[1400px] space-y-6 px-4 pb-16 sm:px-6 lg:px-10">
        <SectionTabs group="rx" class="mb-2" />
        <PageHero
          :title="heroTitle"
          icon="i-lucide-terminal"
          description="Receiver console and diagnostic output."
          :status="heroStatus"
          size="sm"
        />

        <UAlert
          color="warning"
          variant="soft"
          icon="i-lucide-triangle-alert"
          title="Not implemented yet"
          description="RX console is not available: no receiver firmware or API exists yet."
        />

        <ContentSection title="Planned" description="Console capabilities for the future RX firmware.">
          <ul class="list-inside list-disc space-y-1.5 text-sm text-muted">
            <li v-for="item in planned" :key="item">
              {{ item }}
            </li>
          </ul>
        </ContentSection>
      </div>
    </template>
  </UDashboardPanel>
</template>
`,a=`<script setup lang="ts">
import { pageForRoute, pageStatusMeta } from '~/pages.config'

const route = useRoute()
const page = computed(() => pageForRoute(route.path))
const heroTitle = computed(() => page.value?.label ?? 'Hardware')
const heroStatus = computed(() => page.value ? pageStatusMeta(page.value.status) : undefined)

const planned = [
  'Receiver board and radio module selection (WiFi + BLE combo, external antenna)',
  'GPIO mapping for status LED, buzzer and buttons',
  'Channel plan and antenna gain for the scan front-end'
]
<\/script>

<template>
  <UDashboardPanel id="rx-hardware" class="bg-default" :ui="{ root: 'pt-16' }">
    <template #body>
      <div class="mx-auto w-full max-w-[1400px] space-y-6 px-4 pb-16 sm:px-6 lg:px-10">
        <SectionTabs group="rx" class="mb-2" />
        <PageHero
          :title="heroTitle"
          icon="i-lucide-cpu"
          description="Receiver board, radio module and GPIO mapping."
          :status="heroStatus"
          size="sm"
        />

        <UAlert
          color="warning"
          variant="soft"
          icon="i-lucide-triangle-alert"
          title="Not implemented yet"
          description="RX hardware configuration is not available: no receiver firmware exists yet."
        />

        <ContentSection title="Planned" description="Configuration surfaces for the future RX board.">
          <ul class="list-inside list-disc space-y-1.5 text-sm text-muted">
            <li v-for="item in planned" :key="item">
              {{ item }}
            </li>
          </ul>
        </ContentSection>
      </div>
    </template>
  </UDashboardPanel>
</template>
`,o=`<script setup lang="ts">
import { pageForRoute, pageStatusMeta } from '~/pages.config'

const route = useRoute()
const page = computed(() => pageForRoute(route.path))
const heroTitle = computed(() => page.value?.label ?? 'Logging')
const heroStatus = computed(() => page.value ? pageStatusMeta(page.value.status) : undefined)

const planned = [
  'Record every detected broadcast (UAS ID, position, signal, timestamp)',
  'Export detections as CSV / GeoJSON for post-flight analysis',
  'Live log view with filters by UAS ID or operator'
]
<\/script>

<template>
  <UDashboardPanel id="rx-logging" class="bg-default" :ui="{ root: 'pt-16' }">
    <template #body>
      <div class="mx-auto w-full max-w-[1400px] space-y-6 px-4 pb-16 sm:px-6 lg:px-10">
        <SectionTabs group="rx" class="mb-2" />
        <PageHero
          :title="heroTitle"
          icon="i-lucide-file-text"
          description="Capture and export received Remote ID traffic."
          :status="heroStatus"
          size="sm"
        />

        <UAlert
          color="warning"
          variant="soft"
          icon="i-lucide-triangle-alert"
          title="Not implemented yet"
          description="RX logging is not available: no receiver firmware or API exists yet."
        />

        <ContentSection title="Planned" description="Logging capabilities for the future RX firmware.">
          <ul class="list-inside list-disc space-y-1.5 text-sm text-muted">
            <li v-for="item in planned" :key="item">
              {{ item }}
            </li>
          </ul>
        </ContentSection>
      </div>
    </template>
  </UDashboardPanel>
</template>
`,s=`<script setup lang="ts">
import { pageForRoute, pageStatusMeta } from '~/pages.config'

const route = useRoute()
const page = computed(() => pageForRoute(route.path))
const heroTitle = computed(() => page.value?.label ?? 'Memory')
const heroStatus = computed(() => page.value ? pageStatusMeta(page.value.status) : undefined)

const planned = [
  'Capacity used by detection history and packet captures',
  'Retention policy (ring buffer, max detections, auto-purge)',
  'Export and clear of stored captures'
]
<\/script>

<template>
  <UDashboardPanel id="rx-memory" class="bg-default" :ui="{ root: 'pt-16' }">
    <template #body>
      <div class="mx-auto w-full max-w-[1400px] space-y-6 px-4 pb-16 sm:px-6 lg:px-10">
        <SectionTabs group="rx" class="mb-2" />
        <PageHero
          :title="heroTitle"
          icon="i-lucide-database"
          description="Storage for captures, detections and logs."
          :status="heroStatus"
          size="sm"
        />

        <UAlert
          color="warning"
          variant="soft"
          icon="i-lucide-triangle-alert"
          title="Not implemented yet"
          description="RX storage is not available: no receiver firmware exists yet."
        />

        <ContentSection title="Planned" description="Storage management for the future RX firmware.">
          <ul class="list-inside list-disc space-y-1.5 text-sm text-muted">
            <li v-for="item in planned" :key="item">
              {{ item }}
            </li>
          </ul>
        </ContentSection>
      </div>
    </template>
  </UDashboardPanel>
</template>
`,c=`<script setup lang="ts">
import { pageForRoute, pageStatusMeta } from '~/pages.config'

const route = useRoute()
const page = computed(() => pageForRoute(route.path))
const heroTitle = computed(() => page.value?.label ?? 'Receiver')
const heroStatus = computed(() => page.value ? pageStatusMeta(page.value.status) : undefined)

const planned = [
  'Scan WiFi Beacon / NAN and BLE Remote ID broadcasts on the selected channels',
  'Live table of detected drones: UAS ID, operator, position, altitude and speed',
  'Signal strength, first/last seen and estimated distance'
]
<\/script>

<template>
  <UDashboardPanel id="rx-receiver" class="bg-default" :ui="{ root: 'pt-16' }">
    <template #body>
      <div class="mx-auto w-full max-w-[1400px] space-y-6 px-4 pb-16 sm:px-6 lg:px-10">
        <SectionTabs group="rx" class="mb-2" />
        <PageHero
          :title="heroTitle"
          icon="i-lucide-radar"
          description="Receiver antenna, scan channels and live Remote ID detections."
          :status="heroStatus"
          size="sm"
        />

        <UAlert
          color="warning"
          variant="soft"
          icon="i-lucide-triangle-alert"
          title="Not implemented yet"
          description="The current firmware is a transmitter only (OmniRID TX). The RX firmware and API are still to be designed."
        />

        <ContentSection title="Planned" description="What this page will show once the RX firmware exposes an API.">
          <ul class="list-inside list-disc space-y-1.5 text-sm text-muted">
            <li v-for="item in planned" :key="item">
              {{ item }}
            </li>
          </ul>
        </ContentSection>
      </div>
    </template>
  </UDashboardPanel>
</template>
`,l=`<script setup lang="ts">
import { pageForRoute, pageStatusMeta } from '~/pages.config'

const route = useRoute()
const page = computed(() => pageForRoute(route.path))
const heroTitle = computed(() => page.value?.label ?? 'Security')
const heroStatus = computed(() => page.value ? pageStatusMeta(page.value.status) : undefined)

const planned = [
  'Verify Ed25519 signatures on received Remote ID messages',
  'Trust store for known operator / UAS keys',
  'Alert on unsigned or invalid broadcasts'
]
<\/script>

<template>
  <UDashboardPanel id="rx-security" class="bg-default" :ui="{ root: 'pt-16' }">
    <template #body>
      <div class="mx-auto w-full max-w-[1400px] space-y-6 px-4 pb-16 sm:px-6 lg:px-10">
        <SectionTabs group="rx" class="mb-2" />
        <PageHero
          :title="heroTitle"
          icon="i-lucide-shield-check"
          description="Signing keys and trust settings for received broadcasts."
          :status="heroStatus"
          size="sm"
        />

        <UAlert
          color="warning"
          variant="soft"
          icon="i-lucide-triangle-alert"
          title="Not implemented yet"
          description="RX signature verification is not available: no receiver firmware exists yet."
        />

        <ContentSection title="Planned" description="Trust and verification settings for the future RX firmware.">
          <ul class="list-inside list-disc space-y-1.5 text-sm text-muted">
            <li v-for="item in planned" :key="item">
              {{ item }}
            </li>
          </ul>
        </ContentSection>
      </div>
    </template>
  </UDashboardPanel>
</template>
`,u=`<script setup lang="ts">
import { pageForRoute, pageStatusMeta } from '~/pages.config'

const route = useRoute()
const page = computed(() => pageForRoute(route.path))
const heroTitle = computed(() => page.value?.label ?? 'Console')
const heroStatus = computed(() => page.value ? pageStatusMeta(page.value.status) : undefined)
<\/script>

<template>
  <UDashboardPanel id="tools-console" class="bg-default" :ui="{ root: 'pt-16' }">
    <template #body>
      <div class="mx-auto w-full max-w-[1400px] space-y-6 px-4 pb-16 sm:px-6 lg:px-10">
        <SectionTabs group="tx" class="mb-2" />
        <PageHero
          :title="heroTitle"
          icon="i-lucide-terminal"
          description="Inspect live device logs, run maintenance commands and send signed commands."
          :status="heroStatus"
          size="sm"
        />

        <ContentSection title="Serial console" description="A live maintenance terminal for the connected device.">
          <ConsoleTerminal />
        </ContentSection>
      </div>
    </template>
  </UDashboardPanel>
</template>
`,d=`<script setup lang="ts">
import type { ConfigSection } from '~/components/device/ConfigPage.vue'
import { BAUD_RATES, validateConfig as validateDeviceConfig, detectChip } from '~/config/device'
import type { DeviceConfig, Issue } from '~/config/device'
import { useDeviceProfile, protocolOptions } from '~/composables/useDeviceProfile'

const { target, protocol } = useDeviceProfile()

const baudOptions = BAUD_RATES.map(b => ({ label: String(b), value: String(b) }))

const PROTOCOL_TO_NUM: Record<string, number> = { auto: 255, mavlink: 1, msp: 2, nmea: 3, none: 4 }
const NUM_TO_PROTOCOL: Record<number, string> = { 255: 'auto', 1: 'mavlink', 2: 'msp', 3: 'nmea', 4: 'none' }

const isMavlink = computed(() => protocol.value === 'mavlink')

const sysidDescription = computed(() => isMavlink.value
  ? '0 = auto-detect. ⚠ Required when Protocol is MAVLink.'
  : '0 = auto-detect. Required only when a specific protocol is set.')

const sections = computed<ConfigSection[]>(() => [{
  title: 'Serial & Protocol',
  description: 'The UART link between the ESP32 and the flight controller.',
  fields: [
    {
      name: 'protocol', label: 'FC Protocol', type: 'select', value: protocol.value, options: protocolOptions,
      description: 'Set to Auto unless detection fails. Manual override forces a specific protocol.'
    },
    { name: 'baud_rate', label: 'UART Baud Rate', type: 'select', value: '57600', options: baudOptions, description: 'Must match your flight controller serial port speed.' },
    { name: 'target_fcs', label: 'Compatible flight controllers', type: 'chips', options: [
      { label: 'Betaflight', value: '' }, { label: 'ArduPilot', value: '' }, { label: 'INAV', value: '' }
    ] }
  ]
}, {
  title: 'Advanced',
  description: 'MAVLink filtering and startup behaviour.',
  fields: [
    { name: 'mavlink_sysid', label: 'MAVLink SysID', type: 'number', value: 0, stepper: true, description: sysidDescription.value },
    { name: 'bcast_powerup', label: 'Broadcast without GPS', type: 'toggle', value: false, description: 'Send a Basic ID as soon as the device boots, even without a GPS fix.' }
  ]
}])

const mapPayload = (state: Record<string, unknown>): Record<string, unknown> => ({
  protocol: PROTOCOL_TO_NUM[String(state.protocol ?? 'auto')] ?? 255,
  baud_rate: Number(state.baud_rate ?? 57600),
  mavlink_sysid: Number(state.mavlink_sysid ?? 0),
  bcast_powerup: state.bcast_powerup ? 1 : 0
})

const applyLoaded = (cfg: Record<string, unknown>, set: (key: string, value: unknown) => void) => {
  const num = Number(cfg.protocol ?? 255)
  set('protocol', NUM_TO_PROTOCOL[num] ?? 'auto')
  set('baud_rate', String(Number(cfg.baud_rate ?? 57600)))
  set('mavlink_sysid', Number(cfg.mavlink_sysid ?? 0))
  set('bcast_powerup', Number(cfg.bcast_powerup ?? 0) !== 0)
}

const validate = (cfg: DeviceConfig): Issue[] => validateDeviceConfig(cfg, { chip: detectChip(target.value) })

const headerActions = [{ label: 'Wiki', to: '/guide#protocols' }]
<\/script>

<template>
  <DeviceConfigPage
    group="tx"
    description="Configure the UART link between the ESP32 and your flight controller — MAVLink for ArduPilot/PX4, MSP for Betaflight/INAV, or generic NMEA GPS."
    :sections="sections"
    :load="true"
    :validate-config="validate"
    :map-payload="mapPayload"
    :apply-loaded="applyLoaded"
    :header-actions="headerActions"
  />
</template>
`,f=`<script setup lang="ts">
import type { ConfigSection } from '~/components/device/ConfigPage.vue'
import { DEFAULTS, CAN_BITRATES, validateConfig as validateDeviceConfig, detectChip } from '~/config/device'
import type { DeviceConfig, Issue } from '~/config/device'
import { useDeviceProfile } from '~/composables/useDeviceProfile'

const { target } = useDeviceProfile()

const canOptions = CAN_BITRATES.map(b => ({ label: \`\${b / 1000} kbit/s\`, value: String(b) }))
const uartOptions = [0, 1, 2].map(u => ({ label: \`UART \${u}\`, value: String(u) }))

const numField = (name: keyof typeof DEFAULTS, label: string, description?: string) => ({
  name, label, type: 'number' as const, value: DEFAULTS[name] as number, description
})

const sections = computed<ConfigSection[]>(() => [{
  title: 'Flight controller UART',
  description: 'Serial pins wired to the flight controller.',
  fields: [
    { name: 'uart_port', label: 'UART port', type: 'select', value: String(DEFAULTS.uart_port), options: uartOptions },
    numField('tx_pin', 'TX pin', 'UART TX wired to the flight controller RX. -1 disables this input.'),
    numField('rx_pin', 'RX pin', 'UART RX wired to the flight controller TX. -1 disables this input.'),
    { name: 'mavlink_usb_enable', label: 'MAVLink over USB', type: 'toggle', value: false, description: 'ESP32-S3/C6 only: use the USB CDC port as a MAVLink input.' }
  ]
}, {
  title: 'DroneCAN',
  description: 'Optional CAN bus link to a DroneCAN-enabled flight controller.',
  fields: [
    numField('dronecan_rx_gpio', 'DroneCAN RX pin'),
    numField('dronecan_tx_gpio', 'DroneCAN TX pin'),
    { name: 'dronecan_bitrate', label: 'CAN bitrate', type: 'select', value: String(DEFAULTS.dronecan_bitrate), options: canOptions }
  ]
}, {
  title: 'Status LEDs',
  description: 'Simple GPIO LEDs driven by the firmware.',
  fields: [
    numField('led_r_gpio', 'Red LED'),
    numField('led_g_gpio', 'Green LED'),
    numField('led_b_gpio', 'Blue LED')
  ]
}, {
  title: 'Boot & OTA',
  description: 'Safety and update behaviour.',
  fields: [
    numField('ota_trigger_gpio', 'OTA trigger pin', 'Hold this pin at boot to enter firmware update mode.'),
    numField('start_delay_ms', 'Startup delay (ms)', 'Delay before the ESP starts broadcasting after boot.')
  ]
}])

const numberKeys = [
  'uart_port', 'tx_pin', 'rx_pin', 'dronecan_rx_gpio', 'dronecan_tx_gpio', 'dronecan_bitrate',
  'led_r_gpio', 'led_g_gpio', 'led_b_gpio', 'ota_trigger_gpio', 'start_delay_ms'
] as (keyof typeof DEFAULTS)[]

const mapPayload = (state: Record<string, unknown>): Record<string, unknown> => {
  const out: Record<string, unknown> = { mavlink_usb_enable: state.mavlink_usb_enable ? 1 : 0 }
  for (const key of numberKeys) out[key] = Number(state[key] ?? DEFAULTS[key])
  return out
}

const applyLoaded = (cfg: Record<string, unknown>, set: (key: string, value: unknown) => void) => {
  for (const key of numberKeys) set(key, Number(cfg[key] ?? DEFAULTS[key]))
  set('mavlink_usb_enable', Number(cfg.mavlink_usb_enable ?? 0) !== 0)
}

const validate = (cfg: DeviceConfig): Issue[] => validateDeviceConfig(cfg, { chip: detectChip(target.value) })
<\/script>

<template>
  <DeviceConfigPage
    group="tx"
    description="Wire the pins: flight controller UART, DroneCAN, status LEDs and boot behaviour."
    :sections="sections"
    :load="true"
    :validate-config="validate"
    :map-payload="mapPayload"
    :apply-loaded="applyLoaded"
  />
</template>
`,p=`<script setup lang="ts">
import type { ConfigSection } from '~/components/device/ConfigPage.vue'
import { ID_TYPES, UA_TYPES, validateConfig as validateDeviceConfig, detectChip } from '~/config/device'
import type { DeviceConfig, Issue } from '~/config/device'
import { useDeviceProfile } from '~/composables/useDeviceProfile'

const { target } = useDeviceProfile()

const coords = ['operator_lat', 'operator_lon', 'operator_alt'] as const

const idTypeOptions = ID_TYPES.map(t => ({ label: t.label, value: String(t.value) }))
const uaTypeOptions = UA_TYPES.map(t => ({ label: t.label, value: String(t.value) }))
const idType2Options = [{ label: 'None', value: '0' }, ...idTypeOptions]
const uaType2Options = UA_TYPES.slice(0, 1).map(t => ({ label: t.label, value: String(t.value) }))

const sections = computed<ConfigSection[]>(() => [{
  title: 'Aircraft identity',
  description: 'The main Basic ID block broadcast by every transmission.',
  fields: [
    { name: 'uas_id', label: 'UAS ID', type: 'text', value: '', placeholder: 'e.g. 3D3A1234567890ABCD', maxlength: 20, description: 'Serial Number (ANSI/CTA-2063), CAA registration or UUID depending on ID type.' },
    { name: 'id_type', label: 'ID type', type: 'select', value: '1', options: idTypeOptions },
    { name: 'ua_type', label: 'UA type', type: 'select', value: '1', options: uaTypeOptions, description: 'Receivers reject a UA type of None.' }
  ]
}, {
  title: 'Operator identity',
  description: 'Used by regions that require an operator registration number.',
  fields: [
    { name: 'operator_id', label: 'Operator ID', type: 'text', value: '', maxlength: 20, placeholder: 'Typically the national registration number' },
    { name: 'self_id_text', label: 'Self-ID text', type: 'text', value: '', maxlength: 23, description: 'Free text up to 23 ASCII characters.' },
    { name: 'operator_lat', label: 'Operator latitude', type: 'number', value: 0, stepper: true, step: 0.0001, description: 'Leave 0/0 to broadcast the drone position instead.' },
    { name: 'operator_lon', label: 'Operator longitude', type: 'number', value: 0, stepper: true, step: 0.0001 },
    { name: 'operator_alt', label: 'Operator altitude (m)', type: 'number', value: 0, stepper: true, step: 1 }
  ]
}, {
  title: 'Second Basic ID',
  description: 'Optional second identity block, for example a session ID while carrying a different equipment.',
  fields: [
    { name: 'uas_id_2', label: 'UAS ID 2', type: 'text', value: '', maxlength: 20 },
    { name: 'id_type_2', label: 'ID type 2', type: 'select', value: '0', options: idType2Options },
    { name: 'ua_type_2', label: 'UA type 2', type: 'select', value: '0', options: uaType2Options }
  ]
}])

const mapPayload = (state: Record<string, unknown>): Record<string, unknown> => ({
  uas_id: String(state.uas_id ?? ''),
  uas_id_2: String(state.uas_id_2 ?? ''),
  operator_id: String(state.operator_id ?? ''),
  self_id_text: String(state.self_id_text ?? ''),
  operator_lat: Number(state.operator_lat ?? 0),
  operator_lon: Number(state.operator_lon ?? 0),
  operator_alt: Number(state.operator_alt ?? 0),
  id_type: Number(state.id_type ?? 1),
  id_type_2: Number(state.id_type_2 ?? 0),
  ua_type: Number(state.ua_type ?? 1),
  ua_type_2: Number(state.ua_type_2 ?? 0)
})

const applyLoaded = (cfg: Record<string, unknown>, set: (key: string, value: unknown) => void) => {
  set('uas_id', String(cfg.uas_id ?? ''))
  set('uas_id_2', String(cfg.uas_id_2 ?? ''))
  set('operator_id', String(cfg.operator_id ?? ''))
  set('self_id_text', String(cfg.self_id_text ?? ''))
  for (const key of coords) set(key, Number(cfg[key] ?? 0))
  set('id_type', String(Number(cfg.id_type ?? 1)))
  set('id_type_2', String(Number(cfg.id_type_2 ?? 0)))
  set('ua_type', String(Number(cfg.ua_type ?? 1)))
  set('ua_type_2', String(Number(cfg.ua_type_2 ?? 0)))
}

const validate = (cfg: DeviceConfig): Issue[] => validateDeviceConfig(cfg, { chip: detectChip(target.value) })
<\/script>

<template>
  <DeviceConfigPage
    group="tx"
    description="Enter the UAS ID, operator details and the optional second Basic ID broadcast by the drone."
    :sections="sections"
    :load="true"
    :validate-config="validate"
    :map-payload="mapPayload"
    :apply-loaded="applyLoaded"
  />
</template>
`,m=`<script setup lang="ts">
import { pageForRoute, pageStatusMeta } from '~/pages.config'

const route = useRoute()
const page = computed(() => pageForRoute(route.path))
const heroTitle = computed(() => page.value?.label ?? 'Logging')
const heroStatus = computed(() => page.value ? pageStatusMeta(page.value.status) : undefined)

const readings = [
  { name: 'firmware', label: 'Firmware', value: '--' },
  { name: 'gps_fix', label: 'GPS fix', value: '--' },
  { name: 'satellites', label: 'Satellites', value: '--' },
  { name: 'latitude', label: 'Latitude', value: '--' },
  { name: 'longitude', label: 'Longitude', value: '--' },
  { name: 'altitude', label: 'Altitude', value: '--' },
  { name: 'speed', label: 'Speed', value: '--' },
  { name: 'heading', label: 'Heading', value: '--' },
  { name: 'tx_rate', label: 'TX rate', value: '--' },
  { name: 'cpu_temperature', label: 'CPU temperature', value: '--' }
]
<\/script>

<template>
  <UDashboardPanel id="tools-logging" class="bg-default" :ui="{ root: 'pt-16' }">
    <template #body>
      <div class="mx-auto w-full max-w-[1400px] space-y-6 px-4 pb-16 sm:px-6 lg:px-10">
        <SectionTabs group="tx" class="mb-2" />
        <PageHero
          :title="heroTitle"
          icon="i-lucide-file-text"
          description="Record live telemetry while flying or bench-testing, then export it as a CSV file."
          :status="heroStatus"
          size="sm"
        />

        <ContentSection title="Telemetry log" description="Samples are captured every 2 seconds from the device.">
          <TelemetryRecorder />
        </ContentSection>

        <ContentSection title="Live sensor readings" description="Values refresh from the connected device while telemetry is available.">
          <div class="grid gap-5 md:grid-cols-2">
            <UFormField v-for="reading in readings" :key="reading.name" :label="reading.label">
              <UInput :model-value="reading.value" disabled class="w-full" />
            </UFormField>
          </div>
        </ContentSection>
      </div>
    </template>
  </UDashboardPanel>
</template>
`,h=`<script setup lang="ts">
import { pageForRoute, pageStatusMeta } from '~/pages.config'
import {
  NVS_KEY_COUNT,
  NVS_NAMESPACE,
  flashRegions,
  nvsGroups,
  runtimeOnly
} from '~/config/storage'

const route = useRoute()
const page = computed(() => pageForRoute(route.path))
const heroTitle = computed(() => page.value?.label ?? 'Memory')
const heroStatus = computed(() => page.value ? pageStatusMeta(page.value.status) : undefined)

const summary = computed(() => [
  { label: 'NVS namespace', value: NVS_NAMESPACE },
  { label: 'Persisted keys', value: String(NVS_KEY_COUNT) },
  { label: 'Runtime-only', value: String(runtimeOnly.length) },
  { label: 'Flash regions', value: String(flashRegions.length) }
])

const regionTone: Record<string, string> = {
  factory: 'text-muted',
  ota: 'text-primary',
  data: 'text-success'
}
<\/script>

<template>
  <UDashboardPanel id="device-memory" class="bg-default" :ui="{ root: 'pt-16' }">
    <template #body>
      <div class="mx-auto w-full max-w-[1400px] space-y-9 px-4 pb-16 sm:px-6 lg:px-10">
        <SectionTabs group="tx" class="mb-2" />

        <PageHero
          :title="heroTitle"
          icon="i-lucide-database"
          description="Flash layout, NVS persistence and runtime-only settings of the connected device."
          :status="heroStatus"
          size="sm"
        >
          <template #right>
            <dl class="grid grid-cols-2 gap-px overflow-hidden rounded-lg border border-default bg-accented">
              <div v-for="cell in summary" :key="cell.label" class="min-w-0 bg-default px-4 py-3">
                <dt class="label-data">
                  {{ cell.label }}
                </dt>
                <dd class="mt-1 truncate font-mono text-lg font-semibold text-highlighted">
                  {{ cell.value }}
                </dd>
              </div>
            </dl>
          </template>
        </PageHero>

        <!-- Flash layout -->
        <ContentSection
          title="Device flash"
          description="The firmware uses a factory image plus a single OTA slot; configuration lives in its own NVS region."
        >
          <div class="grid gap-px overflow-hidden rounded-lg border border-default bg-accented sm:grid-cols-3">
            <div v-for="region in flashRegions" :key="region.name" class="bg-default p-4">
              <div class="flex items-center justify-between gap-2">
                <code class="font-mono text-sm font-semibold" :class="regionTone[region.tone]">{{ region.name }}</code>
                <span class="label-data">{{ region.app }}</span>
              </div>
              <p class="mt-2 text-xs leading-5 text-muted">
                {{ region.description }}
              </p>
            </div>
          </div>
        </ContentSection>

        <!-- NVS key layout -->
        <ContentSection
          title="NVS persistence"
          :description="\`Configuration is stored as \${NVS_KEY_COUNT} flat keys in the \${NVS_NAMESPACE} namespace and survives reboots and OTA updates until the namespace is erased by a factory reset.\`"
        >
          <div class="space-y-5">
            <div v-for="group in nvsGroups" :key="group.title">
              <p class="label-data mb-2">
                {{ group.title }}
              </p>
              <div class="grid gap-px overflow-hidden rounded-lg border border-default bg-accented">
                <div
                  v-for="row in group.rows"
                  :key="row[0]"
                  class="flex flex-col gap-1 bg-default px-4 py-2.5 sm:grid sm:grid-cols-[minmax(0,9rem)_4.5rem_1fr] sm:items-baseline sm:gap-4"
                >
                  <code class="font-mono text-xs font-medium text-primary">{{ row[0] }}</code>
                  <span class="font-mono text-[11px] text-dimmed">{{ row[1] }}</span>
                  <span class="text-xs leading-5 text-muted">{{ row[2] }}</span>
                </div>
              </div>
            </div>
          </div>
        </ContentSection>

        <!-- Runtime-only -->
        <ContentSection
          title="Not persisted"
          description="These settings live in RAM only and reset to firmware defaults on every reboot."
        >
          <div class="flex flex-wrap gap-1.5">
            <span
              v-for="item in runtimeOnly"
              :key="item"
              class="rounded-sm border border-default bg-elevated/40 px-2.5 py-1 font-mono text-[11px] text-muted"
            >
              {{ item }}
            </span>
          </div>
        </ContentSection>

        <!-- Maintenance -->
        <ContentSection title="Maintenance" description="Resetting or erasing the device is done from the console.">
          <div class="flex flex-wrap items-center gap-3 rounded-lg border border-warning/40 bg-warning/10 p-4">
            <UIcon name="i-lucide-triangle-alert" class="size-5 shrink-0 text-warning" />
            <p class="min-w-0 flex-1 text-sm leading-6 text-muted">
              <span class="font-semibold text-highlighted">Factory reset</span> erases the
              <code class="rounded bg-elevated px-1 font-mono text-xs">{{ NVS_NAMESPACE }}</code>
              namespace and restores defaults. Send <code class="rounded bg-elevated px-1 font-mono text-xs">restart</code>
              or <code class="rounded bg-elevated px-1 font-mono text-xs">reset</code> from the console; both require an
              <code class="rounded bg-elevated px-1 font-mono text-xs">X-Signature</code> when the device is locked.
            </p>
            <UButton
              to="/tx/console"
              color="neutral"
              variant="soft"
              icon="i-lucide-terminal"
              label="Open console"
              class="shrink-0"
            />
          </div>
        </ContentSection>
      </div>
    </template>
  </UDashboardPanel>
</template>
`,g=`<script setup lang="ts">
import type { ConfigSection } from '~/components/device/ConfigPage.vue'
import {
  DEFAULTS, normalizeRegion, hasFlag, setFlag, TX_MODES, REGIONS,
  validateConfig as validateDeviceConfig, detectChip
} from '~/config/device'
import type { DeviceConfig, Issue, RegionCode } from '~/config/device'
import { useDeviceProfile } from '~/composables/useDeviceProfile'

const { target } = useDeviceProfile()

const regionFieldOptions = [
  { label: 'Auto-detect', value: 'auto' },
  ...(Object.keys(REGIONS) as Exclude<RegionCode, 'auto'>[]).map(code => ({ label: REGIONS[code].label, value: code }))
]

const MODE_TOGGLES = [
  { name: 'tx_wifi_bcn', flag: TX_MODES.wifiBeacon, label: 'WiFi Beacon', description: 'Broadcast the Remote ID over a WiFi Beacon as defined by ASTM F3411-22a.' },
  { name: 'tx_wifi_nan', flag: TX_MODES.wifiNan, label: 'WiFi NAN', description: 'Neighbor Awareness Networking, used by GB 42590 and Singapore B-RID.' },
  { name: 'tx_ble4', flag: TX_MODES.ble4, label: 'BLE 4.0', description: 'Classic Bluetooth Low Energy advertising channel.' },
  { name: 'tx_ble5', flag: TX_MODES.ble5, label: 'BLE 5.0 Long Range', description: 'Requires BLE 4.0 active and an ESP32-S3 (experimental).' }
] as const

const rateKeys = ['wifi_bcn_rate_hz', 'wifi_nan_rate_hz', 'ble4_rate_hz', 'ble5_rate_hz'] as (keyof typeof DEFAULTS)[]

const sections = computed<ConfigSection[]>(() => [{
  title: 'Operating region',
  description: 'Select the nation; the firmware picks the matching Remote ID standard.',
  fields: [
    { name: 'region_select', label: 'Region', type: 'select', value: 'auto', options: regionFieldOptions, description: 'Auto-detect defaults to Europe (EASA/EEA).' }
  ]
}, {
  title: 'Transmission schedule',
  description: 'Enable the broadcast interfaces the ESP uses to transmit the Remote ID.',
  fields: [
    ...MODE_TOGGLES.map(t => ({ name: t.name, label: t.label, type: 'toggle' as const, value: false, description: t.description })),
    { name: 'wifi_channel', label: 'WiFi channel', type: 'number', value: DEFAULTS.wifi_channel },
    { name: 'wifi_power_dbm', label: 'WiFi power (dBm)', type: 'number', value: DEFAULTS.wifi_power_dbm },
    { name: 'ble4_power_dbm', label: 'BLE 4.0 power (dBm)', type: 'number', value: DEFAULTS.ble4_power_dbm },
    { name: 'ble5_power_dbm', label: 'BLE 5.0 power (dBm)', type: 'number', value: DEFAULTS.ble5_power_dbm },
    ...rateKeys.map(k => ({ name: k, label: k.replace('_rate_hz', '').replaceAll('_', ' ').toUpperCase() + ' rate (Hz)', type: 'number' as const, value: DEFAULTS[k] }))
  ]
}, {
  title: 'Compliance checklist',
  description: 'Regulatory readiness checks for the selected region and standard.',
  fields: [
    { name: 'identity_ready', label: 'Identity fields complete', type: 'toggle', value: false },
    { name: 'broadcast_ready', label: 'At least one broadcast channel enabled', type: 'toggle', value: true },
    { name: 'gps_ready', label: 'GPS or approved fallback configured', type: 'toggle', value: false },
    { name: 'security_reviewed', label: 'Security settings reviewed', type: 'toggle', value: false }
  ]
}])

const mapPayload = (state: Record<string, unknown>): Record<string, unknown> => {
  let tx_modes = 0
  for (const t of MODE_TOGGLES) tx_modes = setFlag(tx_modes, t.flag, !!state[t.name])
  const num = (key: keyof typeof DEFAULTS) => Number(state[key] ?? DEFAULTS[key])
  return {
    region: normalizeRegion(state.region_select),
    tx_modes,
    wifi_channel: num('wifi_channel'),
    wifi_power_dbm: num('wifi_power_dbm'),
    wifi_bcn_rate_hz: num('wifi_bcn_rate_hz'),
    wifi_nan_rate_hz: num('wifi_nan_rate_hz'),
    ble4_power_dbm: num('ble4_power_dbm'),
    ble4_rate_hz: num('ble4_rate_hz'),
    ble5_power_dbm: num('ble5_power_dbm'),
    ble5_rate_hz: num('ble5_rate_hz')
  }
}

const applyLoaded = (cfg: Record<string, unknown>, set: (key: string, value: unknown) => void) => {
  set('region_select', normalizeRegion(cfg.region))
  const tx = Number(cfg.tx_modes ?? DEFAULTS.tx_modes)
  for (const t of MODE_TOGGLES) set(t.name, hasFlag(tx, t.flag))
  for (const k of rateKeys) set(k, Number(cfg[k] ?? DEFAULTS[k]))
  for (const k of ['wifi_channel', 'wifi_power_dbm', 'ble4_power_dbm', 'ble5_power_dbm'] as (keyof typeof DEFAULTS)[])
    set(k, Number(cfg[k] ?? DEFAULTS[k]))
}

const validate = (cfg: DeviceConfig): Issue[] => validateDeviceConfig(cfg, { chip: detectChip(target.value) })
<\/script>

<template>
  <DeviceConfigPage
    group="tx"
    description="Select the operating nation, Remote ID standard and transmission schedule, and check regulatory compliance."
    :sections="sections"
    :load="true"
    :validate-config="validate"
    :map-payload="mapPayload"
    :apply-loaded="applyLoaded"
  />
</template>
`,_=`<script setup lang="ts">
import { pageForRoute, pageStatusMeta } from '~/pages.config'

const route = useRoute()
const page = computed(() => pageForRoute(route.path))
const heroTitle = computed(() => page.value?.label ?? 'Presets')
const heroStatus = computed(() => page.value ? pageStatusMeta(page.value.status) : undefined)
<\/script>

<template>
  <UDashboardPanel id="tools-presets" class="bg-default" :ui="{ root: 'pt-16' }">
    <template #body>
      <div class="mx-auto w-full max-w-[1400px] space-y-6 px-4 pb-16 sm:px-6 lg:px-10">
        <SectionTabs group="tx" class="mb-2" />
        <PageHero
          :title="heroTitle"
          icon="i-lucide-list"
          description="Capture the current device configuration and save reusable presets for different aircraft and regions."
          :status="heroStatus"
          size="sm"
        />

        <ContentSection title="Configuration profiles" description="Presets are stored in this browser as JSON and can be applied to the device or exported as files.">
          <PresetManager />
        </ContentSection>
      </div>
    </template>
  </UDashboardPanel>
</template>
`,v=`<script setup lang="ts">
import type { ConfigSection, ConfigDanger } from '~/components/device/ConfigPage.vue'
import { LOCK_LEVELS, OPTIONS, hasFlag, setFlag, validateConfig as validateDeviceConfig, detectChip } from '~/config/device'
import type { DeviceConfig, Issue } from '~/config/device'
import { useDeviceProfile } from '~/composables/useDeviceProfile'

const { target } = useDeviceProfile()

const lockOptions = LOCK_LEVELS.map(l => ({ label: l.label, value: String(l.value) }))
const keyOptions = [1, 2, 3, 4, 5].map(i => ({ name: \`public_key_\${i}\`, label: \`Key \${i}\`, type: 'textarea' as const, value: '', placeholder: 'PEM public key or raw base64' }))

const OPTION_TOGGLES = [
  { name: 'opt_force_arm', flag: OPTIONS.forceArm, label: 'Force ARM OK', description: 'Allow arming without safety checks. Test option, never for real flights.' },
  { name: 'opt_no_save_basic_id', flag: OPTIONS.noSaveBasicId, label: 'Don\\'t save BasicID to NVS', description: 'Keep the Basic ID in RAM only; identity must be re-applied on every boot.' },
  { name: 'opt_print_mavlink_rid', flag: OPTIONS.printMavlinkRid, label: 'Print MAVLink RID messages', description: 'Log the outgoing MAVLink Remote ID messages to the console.' },
  { name: 'opt_demo_mode', flag: OPTIONS.demoMode, label: 'Demo mode (simulated GPS patrol)', description: 'Transmit a simulated GPS position for bench testing.' },
  { name: 'opt_kalman', flag: OPTIONS.kalman, label: 'Kalman filter (GPS smoothing)', description: 'Fuse GPS and barometer for a smoother position estimate.' },
  { name: 'opt_ed25519_auth', flag: OPTIONS.ed25519Auth, label: 'Ed25519 auth on transmitted IDs', description: 'Authenticate the transmitted identity with an ed25519 signature.' },
  { name: 'opt_mavlink_arm_gate', flag: OPTIONS.mavlinkArmGate, label: 'MAVLink arm status gate', description: 'Block Remote ID transmission while the flight controller disarms.' },
  { name: 'opt_mavlink_op_loc', flag: OPTIONS.mavlinkOpLoc, label: 'MAVLink operator location loop', description: 'Inject the operator location from MAVLink into the Remote ID stream.' },
  { name: 'opt_identity_gate', flag: OPTIONS.identityGate, label: 'Identity ready gate', description: 'Refuse to transmit while the identity fields are incomplete.' }
] as const

const sections = computed<ConfigSection[]>(() => [{
  title: 'Security & Options',
  description: 'Lock level, startup behaviour flags and the public keys authorised to sign commands.',
  fields: [
    {
      name: 'lock_level', label: 'Lock Level', type: 'select', value: '0', options: lockOptions,
      description: '0 — Normal: no restrictions. 1 — Locked: only commands signed with a registered public key are accepted; the web UI stays accessible but factory reset via CLI requires authentication. 2 — eFuse permanent: burns one-time programmable fuses to enforce the lock; this cannot be undone and may brick the device if keys are lost! Set at least one public key before enabling lock levels 1 or 2.'
    },
    ...OPTION_TOGGLES.map(t => ({ name: t.name, label: t.label, type: 'toggle' as const, value: false, description: t.description })),
    ...keyOptions
  ]
}])

const hasPublicKey = (state: Record<string, unknown>) =>
  [1, 2, 3, 4, 5].some(i => String(state[\`public_key_\${i}\`] ?? '').trim().length > 0)

const danger = (state: Record<string, unknown>): ConfigDanger[] => {
  const lock = Number(state.lock_level ?? 0)
  const keys = hasPublicKey(state)
  const out: ConfigDanger[] = []
  if (lock >= 1 && !keys)
    out.push({
      title: 'Lock needs a public key',
      description: 'Set at least one public key before enabling lock levels 1 or 2: without keys the device becomes unreachable.',
      link: { label: 'Security guide', to: '/guide#security' }
    })
  if (lock === 2)
    out.push({
      title: 'Lock level 2 is permanent',
      description: 'Burns the one-time programmable eFuses to enforce the lock. This cannot be undone and may brick the device if keys are lost.',
      link: { label: 'Security guide', to: '/guide#security' }
    })
  if (state.opt_force_arm === true)
    out.push({ title: 'Force ARM OK is active', description: 'Test option, not for real flights.' })
  return out
}

const mapPayload = (state: Record<string, unknown>): Record<string, unknown> => {
  let options = 0
  for (const t of OPTION_TOGGLES) options = setFlag(options, t.flag, !!state[t.name])
  const out: Record<string, unknown> = { lock_level: Number(state.lock_level ?? 0), options }
  for (let i = 1; i <= 5; i++) out[\`public_key_\${i}\`] = String(state[\`public_key_\${i}\`] ?? '')
  return out
}

const applyLoaded = (cfg: Record<string, unknown>, set: (key: string, value: unknown) => void) => {
  set('lock_level', String(Number(cfg.lock_level ?? 0)))
  const options = Number(cfg.options ?? 0)
  for (const t of OPTION_TOGGLES) set(t.name, hasFlag(options, t.flag))
  for (let i = 1; i <= 5; i++) set(\`public_key_\${i}\`, String(cfg[\`public_key_\${i}\`] ?? ''))
}

const validate = (cfg: DeviceConfig): Issue[] => validateDeviceConfig(cfg, { chip: detectChip(target.value) })
<\/script>

<template>
  <DeviceConfigPage
    group="tx"
    description="Protect the configuration panel and transmitted identity data; lock the device, set startup options and authorise command signing through public keys."
    :sections="sections"
    :load="true"
    :validate-config="validate"
    :map-payload="mapPayload"
    :apply-loaded="applyLoaded"
    :danger="danger"
  />
</template>
`,y=`<script setup lang="ts">
import { defaults, useAppSettings } from '~/composables/useAppSettings'
import type { VirtualConnection } from '~/composables/useAppSettings'

// The scroll area is capped in the desktop popover but should fill the
// available height when hosted in a slideover.
withDefaults(defineProps<{ scrollClass?: string }>(), { scrollClass: 'max-h-[60vh]' })

const { settings } = useAppSettings()

const themeOptions = [
  { label: 'Blue', value: 'blue' },
  { label: 'Violet', value: 'violet' },
  { label: 'Emerald', value: 'emerald' },
  { label: 'Amber', value: 'amber' },
  { label: 'Yellow', value: 'yellow' }
]

const languageOptions = [
  { label: 'English', value: 'en' },
  { label: 'Italiano', value: 'it' }
]

const virtualConnectionOptions: { label: string, value: VirtualConnection, icon: string }[] = [
  { label: 'WiFi', value: 'wifi', icon: 'i-lucide-wifi' },
  { label: 'USB', value: 'usb', icon: 'i-lucide-usb' },
  { label: 'Off', value: 'off', icon: 'i-lucide-power' }
]

const resetSettings = () => {
  settings.value = { ...defaults }
}
<\/script>

<template>
  <div class="flex min-h-0 flex-col">
    <div class="space-y-6 overflow-y-auto px-4 py-4" :class="scrollClass">
      <section>
        <p class="text-xs font-semibold uppercase tracking-[0.18em] text-muted">
          Options
        </p>
        <div class="mt-2 divide-y divide-default border-y border-default">
          <div class="flex items-start justify-between gap-4 py-3">
            <div>
              <p class="text-sm font-medium text-highlighted">
                Enable Expert Mode
              </p>
              <p class="mt-0.5 text-xs text-muted">
                Unlock pages marked as WIP and experimental tools.
              </p>
            </div>
            <USwitch v-model="settings.expertMode" />
          </div>
          <div class="flex items-start justify-between gap-4 py-3">
            <div>
              <p class="text-sm font-medium text-highlighted">
                Reopen last tab on connect
              </p>
              <p class="mt-0.5 text-xs text-muted">
                Restore the last visited page when the ESP gets connected.
              </p>
            </div>
            <USwitch v-model="settings.reopenLastTab" />
          </div>
          <div class="flex items-start justify-between gap-4 py-3">
            <div>
              <p class="text-sm font-medium text-highlighted">
                Disable internet access
              </p>
              <p class="mt-0.5 text-xs text-muted">
                For metered or slow connections. Hides external links.
              </p>
            </div>
            <USwitch v-model="settings.disableInternet" />
          </div>
        </div>
      </section>

      <section>
        <p class="text-xs font-semibold uppercase tracking-[0.18em] text-muted">
          Interface
        </p>
        <div class="mt-2 divide-y divide-default border-y border-default">
          <div class="flex items-start justify-between gap-4 py-3">
            <div>
              <p class="text-sm font-medium text-highlighted">
                Enable dark theme
              </p>
              <p class="mt-0.5 text-xs text-muted">
                Use the dark color scheme instead of the system default.
              </p>
            </div>
            <USwitch v-model="settings.enableDarkTheme" />
          </div>
          <div class="flex items-center justify-between gap-4 py-3">
            <div>
              <p class="text-sm font-medium text-highlighted">
                Color Theme
              </p>
              <p class="mt-0.5 text-xs text-muted">
                Accent color used across the application.
              </p>
            </div>
            <USelect
              v-model="settings.colorTheme"
              :items="themeOptions"
              value-key="value"
              class="w-28 shrink-0"
            />
          </div>
          <div class="flex flex-col gap-3 py-3 sm:flex-row sm:items-center sm:justify-between">
            <div class="flex items-baseline gap-2">
              <p class="text-sm font-medium text-highlighted">
                UI Scale
              </p>
              <span class="rounded-md bg-elevated px-1.5 py-0.5 text-xs tabular-nums text-muted" aria-hidden="true">{{ settings.uiScale }}%</span>
            </div>
            <div class="w-full sm:w-40">
              <USlider
                v-model="settings.uiScale"
                :min="50"
                :max="150"
                :step="5"
              />
            </div>
          </div>
          <div class="flex items-center justify-between gap-4 py-3">
            <div>
              <p class="text-sm font-medium text-highlighted">
                Select default language
              </p>
              <p class="mt-0.5 text-xs text-muted">
                Language shown in the interface.
              </p>
            </div>
            <USelect
              v-model="settings.language"
              :items="languageOptions"
              value-key="value"
              class="w-28 shrink-0"
            />
          </div>
        </div>
      </section>

      <section>
        <p class="text-xs font-semibold uppercase tracking-[0.18em] text-muted">
          Connection
        </p>
        <div class="mt-2 divide-y divide-default border-y border-default">
          <div class="flex flex-col gap-3 py-3">
            <div>
              <p class="text-sm font-medium text-highlighted">
                Virtual connection
              </p>
              <p class="mt-0.5 text-xs text-muted">
                Simulate a WiFi link to the ESP to explore the app without hardware. Off connects to a real device.
              </p>
            </div>
            <div class="flex items-center gap-1 rounded-lg border border-default bg-elevated/60 p-1">
              <button
                v-for="option in virtualConnectionOptions"
                :key="option.value"
                type="button"
                class="flex flex-1 items-center justify-center gap-1.5 rounded-md px-2 py-1.5 text-xs font-medium transition"
                :class="settings.virtualConnection === option.value ? 'bg-primary text-inverted' : 'text-muted hover:text-highlighted'"
                @click="settings.virtualConnection = option.value"
              >
                <UIcon :name="option.icon" class="size-3.5" />
                <span>{{ option.label }}</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      <UAlert
        title="Make a backup before applying presets"
        description="Please make sure you backup your current configuration (Save backup button or via CLI if the button is disabled) before picking and applying presets. Otherwise there is no way to return to previous configuration after applying presets."
        color="warning"
        variant="soft"
        icon="i-lucide-triangle-alert"
      />
    </div>

    <div class="flex items-center justify-between gap-3 border-t border-default px-4 py-3">
      <p class="text-xs text-muted">
        Stored locally on this device.
      </p>
      <UButton
        color="neutral"
        variant="ghost"
        size="sm"
        label="Reset to defaults"
        @click="resetSettings"
      />
    </div>
  </div>
</template>
`,b=`<script setup lang="ts">
const open = defineModel<boolean>('open', { default: false })
<\/script>

<template>
  <UPopover v-model:open="open" :content="{ align: 'end', sideOffset: 8 }">
    <UButton
      color="neutral"
      variant="ghost"
      square
      icon="i-lucide-settings"
      aria-label="Open app settings"
      title="App settings"
    />
    <template #content>
      <div class="w-[26rem] max-w-[calc(100vw-2rem)]">
        <div class="border-b border-default px-4 py-3">
          <p class="text-sm font-semibold text-highlighted">
            App settings
          </p>
          <p class="mt-0.5 text-xs text-muted">
            Preferences for the OmniRID application.
          </p>
        </div>
        <AppSettingsPanel />
      </div>
    </template>
  </UPopover>
</template>
`,x=`<script setup lang="ts">
const { isSettingsOpen } = useDashboard()
<\/script>

<template>
  <USlideover
    v-model:open="isSettingsOpen"
    title="App settings"
    description="Preferences for the OmniRID application."
    :ui="{ body: 'p-0' }"
  >
    <template #body>
      <AppSettingsPanel class="h-full" scroll-class="min-h-0 flex-1" />
    </template>
  </USlideover>
</template>
`,S=`<script setup lang="ts">
import { nextTick, onMounted, watch } from 'vue'
import type { FirmwareLogLevel as LogLevel } from '~/composables/useFirmwareLogs'

const { isEspConnected, proxyFetch } = useEspConnection()
const { lines, push, clear: clearLines } = useFirmwareLogs()
const { notifyError } = useNotifications()
const toast = useToast()

const command = ref('')
const signature = ref('')
const isSending = ref(false)
const autoScroll = ref(true)
const showTimestamps = ref(true)
const levelFilter = ref<'all' | LogLevel>('all')
const history = ref<string[]>([])
const historyCursor = ref(-1)
const scrollRef = ref<HTMLElement | null>(null)

const levelTag: Record<LogLevel, string> = {
  debug: 'D',
  info: 'I',
  warning: 'W',
  error: 'E',
  command: '>'
}

const levelTagClass: Record<LogLevel, string> = {
  debug: 'text-neutral-700',
  info: 'text-neutral-500',
  warning: 'text-amber-600/80',
  error: 'text-red-500/80',
  command: 'text-sky-500/80'
}

const levelTextClass: Record<LogLevel, string> = {
  debug: 'text-neutral-600',
  info: 'text-neutral-200',
  warning: 'text-amber-400',
  error: 'text-red-400',
  command: 'text-sky-400'
}

const visibleLines = computed(() =>
  levelFilter.value === 'all' ? lines.value : lines.value.filter(line => line.level === levelFilter.value)
)

const filterOptions = computed(() => {
  const byLevel = (level: LogLevel) => lines.value.filter(line => line.level === level).length
  return [
    { value: 'all' as const, label: 'All', count: lines.value.length },
    { value: 'debug' as const, label: 'Debug', count: byLevel('debug') },
    { value: 'info' as const, label: 'Info', count: byLevel('info') },
    { value: 'warning' as const, label: 'Warn', count: byLevel('warning') },
    { value: 'error' as const, label: 'Error', count: byLevel('error') }
  ]
})

const formatTime = (at: number) => new Date(at).toLocaleTimeString([], { hour12: false })

const quickCommands = [
  { cmd: 'status', destructive: false },
  { cmd: 'restart', destructive: true },
  { cmd: 'reset', destructive: true }
]

const scrollToBottom = async () => {
  if (!autoScroll.value || !scrollRef.value) return
  await nextTick()
  scrollRef.value.scrollTop = scrollRef.value.scrollHeight
}

watch(() => visibleLines.value.length, scrollToBottom)

const clearOutput = () => {
  clearLines()
}

const copyOutput = async () => {
  const text = lines.value.map(line => line.text).join('\\n')
  if (!text) return
  await navigator.clipboard.writeText(text)
}

const send = async () => {
  const cmd = command.value.trim()
  if (!cmd || isSending.value) return

  push('command', \`> \${cmd}\`)
  command.value = ''
  historyCursor.value = -1
  history.value = [cmd, ...history.value.filter(item => item !== cmd)].slice(0, 50)
  signature.value = signature.value.trim()

  isSending.value = true
  try {
    const headers: Record<string, string> = {}
    if (signature.value) headers['X-Signature'] = signature.value
    await proxyFetch<{ ok?: boolean, error?: string }>('api/command', {
      method: 'POST',
      body: cmd,
      headers,
      timeout: 5000
    })
    push('info', 'Command accepted.')
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Request failed'
    push('error', \`Command rejected: \${message}.\`)
    notifyError('Command rejected', \`\${cmd}: \${message}\`)
    toast.add({
      title: 'Command rejected',
      description: \`\${cmd}: \${message}\`,
      icon: 'i-lucide-circle-alert',
      color: 'error'
    })
  } finally {
    isSending.value = false
  }
}

const onKeydown = (event: KeyboardEvent) => {
  if (event.key === 'ArrowUp') {
    event.preventDefault()
    if (history.value.length === 0) return
    historyCursor.value = Math.min(historyCursor.value + 1, history.value.length - 1)
    command.value = history.value[historyCursor.value] ?? ''
  } else if (event.key === 'ArrowDown') {
    event.preventDefault()
    historyCursor.value = Math.max(historyCursor.value - 1, -1)
    command.value = historyCursor.value >= 0 ? history.value[historyCursor.value] ?? '' : ''
  }
}

const inputRef = ref<{ inputRef?: HTMLInputElement } | null>(null)

const focusInput = () => {
  inputRef.value?.inputRef?.focus()
}

const useQuickCommand = (cmd: string) => {
  command.value = cmd
  focusInput()
}

onMounted(() => {
  nextTick(() => focusInput())
})

const termInputUi = {
  root: '!bg-neutral-900',
  base: '!border-neutral-800 !bg-neutral-900 !text-neutral-100 !placeholder:text-neutral-500',
  leadingIcon: '!text-neutral-500'
}

const ghostUi = {
  label: '!text-neutral-400',
  leadingIcon: '!text-neutral-400'
}
<\/script>

<template>
  <div class="space-y-3">
    <div class="overflow-hidden rounded-lg border border-neutral-700/70 bg-neutral-950 shadow-sm">
      <div class="border-b border-neutral-800 bg-neutral-900">
        <div class="flex flex-wrap items-center justify-between gap-2 px-3 py-2">
          <p class="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.18em] text-neutral-400">
            <span class="relative flex size-2">
              <span
                v-if="isEspConnected"
                class="absolute inline-flex size-full animate-ping rounded-full bg-emerald-500 opacity-60"
              />
              <span class="relative inline-flex size-2 rounded-full" :class="isEspConnected ? 'bg-emerald-500' : 'bg-neutral-600'" />
            </span>
            <span class="hidden sm:inline">{{ isEspConnected ? 'Live log' : 'Offline' }}</span>
          </p>
          <div class="flex items-center gap-1">
            <UButton
              color="neutral"
              variant="ghost"
              size="xs"
              icon="i-lucide-clock"
              class="hover:!bg-neutral-800"
              :ui="ghostUi"
              :aria-label="showTimestamps ? 'Hide timestamps' : 'Show timestamps'"
              @click="showTimestamps = !showTimestamps"
            >
              <span class="hidden lg:inline">{{ showTimestamps ? 'Timestamps on' : 'Timestamps off' }}</span>
            </UButton>
            <UButton
              color="neutral"
              variant="ghost"
              size="xs"
              icon="i-lucide-chevrons-down"
              class="hover:!bg-neutral-800"
              :ui="ghostUi"
              :aria-label="autoScroll ? 'Auto-scroll on' : 'Auto-scroll off'"
              @click="autoScroll = !autoScroll"
            >
              <span class="hidden lg:inline">{{ autoScroll ? 'Auto-scroll on' : 'Auto-scroll off' }}</span>
            </UButton>
            <UButton
              color="neutral"
              variant="ghost"
              size="xs"
              icon="i-lucide-copy"
              :disabled="!lines.length"
              class="hover:!bg-neutral-800"
              :ui="ghostUi"
              aria-label="Copy output"
              @click="copyOutput"
            >
              <span class="hidden md:inline">Copy</span>
            </UButton>
            <UButton
              color="neutral"
              variant="ghost"
              size="xs"
              icon="i-lucide-trash"
              :disabled="!lines.length"
              class="hover:!bg-neutral-800"
              :ui="ghostUi"
              aria-label="Clear output"
              @click="clearOutput"
            >
              <span class="hidden md:inline">Clear</span>
            </UButton>
          </div>
        </div>

        <div class="flex flex-wrap items-center gap-1 border-t border-neutral-800 px-3 py-1.5">
          <button
            v-for="option in filterOptions"
            :key="option.value"
            type="button"
            class="flex items-center gap-1.5 rounded-sm px-2 py-0.5 font-mono text-[11px] transition-colors"
            :class="levelFilter === option.value ? 'bg-neutral-700 text-neutral-100' : 'text-neutral-400 hover:bg-neutral-800'"
            @click="levelFilter = option.value"
          >
            {{ option.label }}
            <span class="text-neutral-500">{{ option.count }}</span>
          </button>
          <span class="ml-auto font-mono text-[11px] text-neutral-500">{{ visibleLines.length }}/{{ lines.length }} lines</span>
        </div>
      </div>

      <div ref="scrollRef" class="h-80 overflow-y-auto p-4 font-mono text-[13px] leading-6">
        <p v-if="!visibleLines.length" class="text-neutral-600">
          {{ lines.length
            ? 'No lines match this filter.'
            : isEspConnected
              ? 'Waiting for logs…'
              : 'ESP not connected — logs appear once the device is reachable.' }}
        </p>
        <p
          v-for="line in visibleLines"
          :key="line.id"
          class="flex gap-2 whitespace-pre-wrap break-words"
        >
          <span class="w-4 shrink-0 select-none text-center text-xs" :class="levelTagClass[line.level]">{{ levelTag[line.level] }}</span>
          <span v-if="showTimestamps" class="shrink-0 select-none text-[11px] text-neutral-500">{{ formatTime(line.at) }}</span>
          <span class="min-w-0" :class="levelTextClass[line.level]">{{ line.text }}</span>
        </p>
      </div>
    </div>

    <div class="space-y-2 overflow-hidden rounded-lg border border-neutral-700/70 bg-neutral-950 p-3 shadow-sm">
      <div class="flex gap-2">
        <span class="flex items-center pl-1 font-mono text-sm font-semibold text-sky-400">$</span>
        <UInput
          ref="inputRef"
          v-model="command"
          class="flex-1"
          placeholder="status, restart, reset…"
          aria-label="CLI command"
          :disabled="isSending"
          :ui="termInputUi"
          @keydown.enter.prevent="send"
          @keydown="onKeydown"
        />
        <UButton
          type="button"
          color="primary"
          icon="i-lucide-send"
          label="Send"
          :loading="isSending"
          :disabled="!command.trim()"
          @click="send"
        />
      </div>
      <div class="flex flex-wrap items-center gap-1.5">
        <span class="text-[11px] uppercase tracking-wider text-neutral-500">Quick</span>
        <button
          v-for="quick in quickCommands"
          :key="quick.cmd"
          type="button"
          class="rounded-sm border border-neutral-700 px-2 py-0.5 font-mono text-[11px] transition-colors hover:bg-neutral-800"
          :class="quick.destructive ? 'text-amber-400' : 'text-neutral-300'"
          @click="useQuickCommand(quick.cmd)"
        >
          {{ quick.cmd }}
        </button>
      </div>
      <div class="flex flex-wrap items-center gap-2">
        <UInput
          v-model="signature"
          class="w-full sm:w-80"
          placeholder="X-Signature (required when device is locked)"
          icon="i-lucide-key-round"
          aria-label="Command signature"
          :ui="termInputUi"
        />
        <p class="text-xs text-neutral-500">
          Use ↑ / ↓ to recall commands.
        </p>
      </div>
    </div>

    <p class="text-xs text-muted">
      Logs: <code class="rounded bg-elevated px-1">GET /api/logs</code> ·
      Commands: <code class="rounded bg-elevated px-1">POST /api/command</code> (restart and reset require an <code class="rounded bg-elevated px-1">X-Signature</code> when locked).
    </p>
  </div>
</template>
`,C=`<script setup lang="ts">
const props = defineProps<{
  caption?: string
  title?: string
  description?: string
  heading?: 'sm' | 'md' | 'lg'
  icon?: string
  iconClass?: string
  framed?: boolean
}>()

const slots = useSlots()

const headingClass = {
  sm: 'text-base',
  md: 'text-lg',
  lg: 'text-xl'
}[props.heading ?? 'md']
<\/script>

<template>
  <section class="min-w-0">
    <div v-if="title || caption || slots.actions" class="mb-4">
      <div class="flex items-center gap-3">
        <div v-if="icon" class="flex size-7 shrink-0 items-center justify-center rounded-sm bg-primary/10 text-primary" :class="iconClass">
          <UIcon :name="icon" class="size-4" />
        </div>
        <div v-else-if="caption" class="label-data shrink-0">
          {{ caption }}
        </div>
        <h2 v-if="title" class="text-display shrink-0 text-highlighted" :class="headingClass">
          {{ title }}
        </h2>
        <div class="h-px flex-1 bg-accented" aria-hidden="true" />
        <div v-if="slots.actions" class="shrink-0">
          <slot name="actions" />
        </div>
      </div>
      <p v-if="description" class="mt-2 max-w-3xl text-sm leading-6 text-muted">
        {{ description }}
      </p>
    </div>

    <div v-if="framed" class="rounded-lg border border-default bg-elevated/40 p-4 sm:p-5">
      <slot />
    </div>
    <slot v-else />
  </section>
</template>
`,w=`<script setup lang="ts">
import type { TelemetryStatus } from '~/composables/useTelemetry'
import type {
  LeafletIcon, LeafletLatLng, LeafletLayer, LeafletMap, LeafletMarker, LeafletPolyline, LeafletStatic
} from '~/types/leaflet'

export interface NearbyDrone {
  id?: string
  uas_id?: string
  uav_id?: string
  serial?: string
  lat?: number | string
  lng?: number | string
  lon?: number | string
  alt?: number | string
  altitude?: number | string
  speed?: number | string
  heading?: number | string
  operator_id?: string
  operator?: string
  registration?: string
  rssi?: number | string
  last_seen?: number | string
  source?: string
  [key: string]: unknown
}

const props = withDefaults(defineProps<{
  status?: TelemetryStatus
  heightClass?: string
  nearbyDrones?: NearbyDrone[]
  showNearby?: boolean
}>(), {
  status: () => ({}),
  heightClass: 'h-[55vh] min-h-[420px]',
  nearbyDrones: () => [],
  showNearby: true
})

const colorMode = useColorMode()

const isDark = computed(() => colorMode.value === 'dark')

const TILE_URLS = {
  dark: 'https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/{z}/{y}/{x}',
  light: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}'
}

const TILE_ATTRIBUTION = {
  dark: 'Tiles &copy; Esri &mdash; Esri, DeLorme, NAVTEQ',
  light: 'Tiles &copy; Esri &mdash; Source: Esri, USGS, NOAA'
}

const LOCAL_JS = '/vendor/leaflet/leaflet.js'
const LOCAL_CSS = '/vendor/leaflet/leaflet.css'
const CDN_JS = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'
const CDN_CSS = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'
const MAX_HISTORY = 300

const mapEl = ref<HTMLDivElement | null>(null)
const follow = ref(true)
const loading = ref(true)
const mapReady = ref(false)
const loadFailed = ref(false)

let link: LeafletStatic | null = null
let map: LeafletMap | null = null
let droneMarker: LeafletMarker | null = null
let takeoffMarker: LeafletMarker | null = null
let homeIcon: LeafletIcon | null = null
let nearbyIcon: LeafletIcon | null = null
let pathLine: LeafletPolyline | null = null
let tileLayer: LeafletLayer | null = null
const nearbyMarkers = new Map<string, LeafletMarker>()
let hasCentered = false
let loadPromise: Promise<LeafletStatic | null> | null = null
const history: LeafletLatLng[] = []

const showNearbyLayer = ref(true)
const selectedDrone = ref<NearbyDrone | null>(null)
const selectedOwn = ref(false)
const showPath = ref(true)

const toggleTheme = () => {
  colorMode.preference = colorMode.value === 'dark' ? 'light' : 'dark'
}

const fmtNum = (v: unknown, digits = 1) => {
  const n = Number(v)
  return Number.isFinite(n) ? n.toFixed(digits) : '--'
}

const fmtInt = (v: unknown) => {
  const n = Number(v)
  return Number.isFinite(n) ? Math.round(n).toString() : '--'
}

const ownInfo = computed(() => {
  const s = props.status ?? {}
  const pos = currentPosition()
  return {
    lat: pos?.lat ?? Number(s.lat),
    lng: pos?.lng ?? Number(s.lon),
    alt: fmtNum(s.alt),
    altMsl: fmtNum(s.alt_msl ?? s.altitude_msl),
    speed: fmtNum(s.speed),
    vSpeed: fmtNum(s.speed_vertical ?? s.climb_rate),
    heading: Number(s.heading) || 0,
    sats: Number(s.satellites) || 0,
    fix: s.gps_valid ? 'Yes' : 'No',
    fixType: s.fix_type ?? '--',
    protocol: s.protocol ?? '--',
    standard: s.standard ?? '--',
    fw: s.fw_version ?? '--',
    uptime: s.uptime_ms ? \`\${Math.round(Number(s.uptime_ms) / 1000)}s\` : '--',
    txTotal: fmtInt(s.tx_total),
    latRaw: Number(s.lat),
    lonRaw: Number(s.lon)
  }
})

const hasOwnPos = computed(() => currentPosition() !== null)

const currentPosition = (): LeafletLatLng | null => {
  const s = props.status ?? {}
  if (!s.gps_valid) return null
  const lat = Number(s.lat)
  const lon = Number(s.lon)
  if (!Number.isFinite(lat) || !Number.isFinite(lon)) return null
  if (lat === 0 && lon === 0) return null
  return { lat, lng: lon }
}

const injectScript = (src: string): Promise<boolean> => new Promise((resolve) => {
  const script = document.createElement('script')
  script.src = src
  script.async = true
  script.onload = () => resolve(true)
  script.onerror = () => resolve(false)
  document.head.appendChild(script)
})

const ensureLeaflet = (): Promise<LeafletStatic | null> => {
  if (typeof window === 'undefined') return Promise.resolve(null)
  if (window.L) return Promise.resolve(window.L)
  if (!loadPromise) {
    loadPromise = (async () => {
      const w = window as Window & typeof globalThis
      try {
        const localCss = document.createElement('link')
        localCss.rel = 'stylesheet'
        localCss.href = LOCAL_CSS
        document.head.appendChild(localCss)

        const localOk = await injectScript(LOCAL_JS)
        if (!w.L && !localOk) {
          const cdnCss = document.createElement('link')
          cdnCss.rel = 'stylesheet'
          cdnCss.href = CDN_CSS
          document.head.appendChild(cdnCss)
          await injectScript(CDN_JS)
        }
        if (!w.L) {
          loadFailed.value = true
          loading.value = false
          return null
        }
        loading.value = false
        return w.L
      } catch {
        loadFailed.value = true
        loading.value = false
        return null
      }
    })()
  }
  return loadPromise
}

const makeDroneIcon = (rotation: number): LeafletIcon | null => {
  if (!link) return null
  const deg = Number.isFinite(rotation) ? Math.round(((rotation % 360) + 360) % 360) : 0
  return link.divIcon({
    className: 'cd-cardiv',
    html: \`<div class="cd-map-drone" style="transform: rotate(\${deg}deg)"></div>\`,
    iconSize: [26, 26],
    iconAnchor: [13, 13]
  })
}

const buildDronePopup = (pos: LeafletLatLng): string => {
  const s = props.status ?? {}
  const fmt = (v: unknown, digits = 1) => {
    const n = Number(v)
    return Number.isFinite(n) ? n.toFixed(digits) : '--'
  }
  return [
    '<div style="min-width:150px;font-family:ui-monospace,monospace;font-size:11px;line-height:1.5">',
    '<b>My Drone</b><br>',
    \`Lat \${pos.lat.toFixed(6)}<br>\`,
    \`Lon \${pos.lng.toFixed(6)}<br>\`,
    \`Alt \${fmt(s.alt)} m · Speed \${fmt(s.speed)} m/s<br>\`,
    \`Heading \${Number(s.heading) || 0}° · Sats \${Number(s.satellites) || 0} · Fix \${s.gps_valid ? 'Yes' : 'No'}\`,
    '</div>'
  ].join('')
}

const buildHomePopup = (pos: LeafletLatLng): string => {
  const s = props.status ?? {}
  const fmt = (v: unknown, digits = 1) => {
    const n = Number(v)
    return Number.isFinite(n) ? n.toFixed(digits) : '--'
  }
  return [
    '<div style="min-width:150px;font-family:ui-monospace,monospace;font-size:12px;line-height:1.5">',
    '<b>Take-off</b><br>',
    \`Lat \${pos.lat.toFixed(6)}<br>\`,
    \`Lon \${pos.lng.toFixed(6)}<br>\`,
    \`Alt \${fmt(s.takeoff_alt)} m\`,
    '</div>'
  ].join('')
}

const syncDrone = (pos: LeafletLatLng | null) => {
  if (!link || !map) return
  if (pos) {
    const icon = makeDroneIcon(Number(props.status?.heading ?? 0))
    if (!icon) return
    if (!droneMarker) {
      droneMarker = link.marker(pos, { icon }).addTo(map)
      const dm = droneMarker as unknown as { on?: (e: string, fn: () => void) => void }
      dm.on?.('click', () => {
        selectedOwn.value = true
        selectedDrone.value = null
      })
    } else {
      droneMarker.setLatLng(pos)
      droneMarker.setIcon(icon)
    }
    droneMarker.bindPopup(buildDronePopup(pos))
    return
  }
  if (droneMarker) {
    map.removeLayer(droneMarker)
    droneMarker = null
  }
}

const syncTakeoff = () => {
  if (!link || !map) return
  const s = props.status ?? {}
  const lat = Number(s.takeoff_lat)
  const lon = Number(s.takeoff_lon)
  const captured = !!s.takeoff_captured && Number.isFinite(lat) && Number.isFinite(lon) && (lat !== 0 || lon !== 0)
  if (captured) {
    const pos: LeafletLatLng = { lat, lng: lon }
    if (!takeoffMarker) {
      takeoffMarker = homeIcon ? link.marker(pos, { icon: homeIcon }).addTo(map) : null
      if (!takeoffMarker) return
      takeoffMarker.bindPopup(buildHomePopup(pos))
    } else {
      takeoffMarker.setLatLng(pos)
      takeoffMarker.bindPopup(buildHomePopup(pos))
    }
    return
  }
  if (takeoffMarker) {
    map.removeLayer(takeoffMarker)
    takeoffMarker = null
  }
}

const syncPath = () => {
  if (!link || !map) return
  if (history.length >= 2) {
    const points = [...history]
    if (!pathLine) {
      pathLine = link.polyline(points, {
        color: '#3b82f6',
        weight: 4,
        opacity: 0.9,
        lineJoin: 'round',
        lineCap: 'round'
      }).addTo(map)
    } else {
      pathLine.setLatLngs(points)
    }
    return
  }
  if (pathLine) {
    map.removeLayer(pathLine)
    pathLine = null
  }
}

const nearbyKey = (d: NearbyDrone) => {
  return String(d.id ?? d.uas_id ?? d.uav_id ?? d.serial ?? \`\${d.lat},\${d.lng}\`)
}

const buildNearbyPopup = (d: NearbyDrone): string => {
  const fmt = (v: unknown, digits = 1) => {
    const n = Number(v)
    return Number.isFinite(n) ? n.toFixed(digits) : '--'
  }
  const id = d.uas_id ?? d.uav_id ?? d.serial ?? d.id ?? '--'
  const op = d.operator_id ?? d.operator ?? '--'
  const reg = d.registration ?? '--'
  const alt = d.altitude ?? d.alt
  return [
    '<div style="min-width:160px;font-family:ui-monospace,monospace;font-size:11px;line-height:1.5">',
    '<b>Nearby Remote ID</b><br>',
    \`UAS ID: \${id}<br>\`,
    \`Operator: \${op}<br>\`,
    \`Reg: \${reg}<br>\`,
    \`Alt \${fmt(alt)} m · Speed \${fmt(d.speed)} m/s<br>\`,
    \`Heading \${Number(d.heading) || 0}° · RSSI \${d.rssi ?? '--'}\`,
    '</div>'
  ].join('')
}

const syncNearby = () => {
  if (!link || !map || !props.showNearby) return
  const seen = new Set<string>()
  for (const d of props.nearbyDrones) {
    const lat = Number((d.lat as unknown) ?? (d as Record<string, unknown>).latitude)
    const lng = Number((d.lng as unknown) ?? (d.lon as unknown) ?? (d as Record<string, unknown>).longitude)
    if (!Number.isFinite(lat) || !Number.isFinite(lng) || (lat === 0 && lng === 0)) continue
    const key = nearbyKey(d)
    seen.add(key)
    const pos: LeafletLatLng = { lat, lng }
    if (!nearbyIcon) {
      nearbyIcon = link.divIcon({
        className: 'cd-cardiv',
        html: '<div class="cd-map-nearby"></div>',
        iconSize: [18, 18],
        iconAnchor: [9, 9]
      })
    }
    if (!nearbyMarkers.has(key)) {
      const marker = link.marker(pos, { icon: nearbyIcon }).addTo(map)
      marker.bindPopup(buildNearbyPopup(d))
      const m = marker as unknown as { on?: (e: string, fn: () => void) => void }
      m.on?.('click', () => {
        selectedDrone.value = d
        selectedOwn.value = false
      })
      nearbyMarkers.set(key, marker)
    } else {
      const marker = nearbyMarkers.get(key)!
      const mm = marker as unknown as { setLatLng?: (p: LeafletLatLng) => void }
      mm.setLatLng?.(pos)
      marker.bindPopup(buildNearbyPopup(d))
    }
  }
  for (const [key, marker] of nearbyMarkers.entries()) {
    if (!seen.has(key)) {
      map.removeLayer(marker)
      nearbyMarkers.delete(key)
    }
  }
}

const applyStatus = () => {
  if (!link || !map) return
  const pos = currentPosition()
  if (pos && showPath.value) {
    history.push(pos)
    if (history.length > MAX_HISTORY) history.shift()
  }
  syncDrone(pos)
  syncTakeoff()
  if (showPath.value) syncPath()
  else if (pathLine) {
    map.removeLayer(pathLine)
    pathLine = null
  }
  syncNearby()
  if (pos) {
    if (!hasCentered) {
      map.setView(pos, 16)
      hasCentered = true
    } else if (follow.value) {
      map.panTo(pos, { animate: false })
    }
  }
}

const recenter = () => {
  if (!map) return
  follow.value = true
  const pos = currentPosition()
  if (pos) map.setView(pos, 16)
}

const addTileLayer = () => {
  if (!link || !map) return
  if (tileLayer) {
    map.removeLayer(tileLayer)
    tileLayer = null
  }
  tileLayer = link.tileLayer(TILE_URLS[isDark.value ? 'dark' : 'light'], {
    maxZoom: 16,
    attribution: TILE_ATTRIBUTION[isDark.value ? 'dark' : 'light']
  }).addTo(map)
}

onMounted(async () => {
  if (false || !mapEl.value) return
  link = await ensureLeaflet()
  if (!link || !mapEl.value) return
  const pos = currentPosition()
  map = link.map(mapEl.value, {
    center: pos ? link.latLng(pos.lat, pos.lng) : link.latLng(0, 0),
    zoom: pos ? 16 : 2,
    zoomControl: true,
    attributionControl: true
  })
  mapReady.value = true
  addTileLayer()
  homeIcon = link.divIcon({
    className: 'cd-cardiv',
    html: '<div class="cd-map-home"><svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg></div>',
    iconSize: [28, 28],
    iconAnchor: [14, 14]
  })
  map.on('dragstart', () => {
    follow.value = false
  })
  mapEl.value.addEventListener('wheel', () => {
    follow.value = false
  }, { passive: true })
  applyStatus()
  requestAnimationFrame(() => map?.invalidateSize())
})

onBeforeUnmount(() => {
  map?.remove()
  map = null
  droneMarker = null
  takeoffMarker = null
  pathLine = null
  tileLayer = null
  for (const mm of nearbyMarkers.values()) {
    const m2 = map as unknown as { removeLayer?: (l: unknown) => void } | null
    m2?.removeLayer?.(mm)
  }
  nearbyMarkers.clear()
})

watch(() => props.status, applyStatus, { deep: true })
watch(() => props.nearbyDrones, () => {
  applyStatus()
}, { deep: true })
watch(isDark, () => {
  if (mapReady.value) addTileLayer()
})
<\/script>

<template>
  <div class="relative w-full overflow-hidden bg-elevated" :class="[heightClass, $attrs.class]" data-drone-map>
    <div ref="mapEl" class="h-full w-full" />
    <div
      v-if="loading && !loadFailed"
      class="pointer-events-none absolute inset-0 flex flex-col items-center justify-center gap-3 p-6 text-center"
    >
      <UIcon name="i-lucide-loader-circle" class="size-6 animate-spin text-muted" />
      <p class="text-sm text-muted">
        Loading map…
      </p>
    </div>
    <div
      v-if="!loading && !loadFailed && mapReady && !currentPosition()"
      class="pointer-events-none absolute inset-0 flex flex-col items-center justify-center gap-2 p-6 text-center"
    >
      <UIcon name="i-lucide-crosshair" class="size-6 text-muted" />
      <p class="text-sm font-medium text-muted">
        Waiting for GPS fix…
      </p>
      <p class="text-xs text-muted/80">
        The live position will appear here. Connect the ESP or enable the simulation.
      </p>
    </div>
    <div
      v-if="loadFailed"
      class="absolute inset-0 z-[1002] flex flex-col items-center justify-center gap-3 bg-elevated p-6 text-center"
    >
      <UIcon name="i-lucide-triangle-alert" class="size-6 text-warning" />
      <p class="text-sm text-muted">
        Unable to load the map. Check the connection and try again.
      </p>
    </div>
    <div class="pointer-events-none absolute right-3 top-3 z-[1001] flex flex-col items-end gap-2">
      <div class="pointer-events-auto flex flex-col gap-1 rounded-lg border border-default bg-default/90 p-1 shadow-md">
        <UButton
          color="neutral"
          variant="ghost"
          size="xs"
          square
          :icon="colorMode.value === 'dark' ? 'i-lucide-sun' : 'i-lucide-moon'"
          aria-label="Toggle map theme"
          title="Toggle map theme"
          @click="toggleTheme"
        />
        <UButton
          v-if="!loadFailed"
          color="neutral"
          variant="ghost"
          size="xs"
          square
          icon="i-lucide-locate-fixed"
          aria-label="Re-center on drone"
          title="Re-center on drone"
          @click="recenter"
        />
        <UButton
          color="neutral"
          variant="ghost"
          size="xs"
          square
          :icon="showPath ? 'i-lucide-route' : 'i-lucide-route-off'"
          aria-label="Toggle flight path"
          title="Toggle flight path"
          @click="showPath = !showPath; applyStatus()"
        />
        <UButton
          v-if="props.nearbyDrones.length"
          color="neutral"
          variant="ghost"
          size="xs"
          square
          :icon="showNearbyLayer ? 'i-lucide-radar' : 'i-lucide-radar-off'"
          aria-label="Toggle nearby drones"
          title="Toggle nearby drones"
          @click="showNearbyLayer = !showNearbyLayer"
        />
      </div>
      <div
        v-if="props.nearbyDrones.length"
        class="pointer-events-auto rounded-lg border border-default bg-default/90 px-2 py-1 text-[11px] text-muted shadow-md"
      >
        {{ props.nearbyDrones.length }} nearby
      </div>
    </div>

    <div
      v-if="selectedOwn && hasOwnPos"
      class="pointer-events-auto absolute bottom-7 left-3 z-[1001] w-[min(360px,calc(100vw-1.5rem))] rounded-lg border border-default bg-default/95 shadow-xl"
    >
      <div class="flex items-center justify-between gap-2 border-b border-default px-3 py-2">
        <div class="flex items-center gap-2">
          <UIcon name="i-lucide-plane" class="size-4 text-primary" />
          <p class="text-sm font-semibold text-highlighted">
            My Drone
          </p>
          <UBadge
            size="xs"
            variant="subtle"
            color="neutral"
            :label="String(ownInfo.standard)"
          />
        </div>
        <UButton
          color="neutral"
          variant="ghost"
          size="xs"
          icon="i-lucide-x"
          @click="selectedOwn = false"
        />
      </div>
      <div class="grid grid-cols-2 gap-2 px-3 py-2 text-xs">
        <div class="col-span-2">
          <p class="text-muted">
            Position (lat, lon)
          </p>
          <p class="font-mono text-highlighted">
            {{ ownInfo.lat.toFixed(6) }}, {{ ownInfo.lng.toFixed(6) }}
          </p>
        </div>
        <div>
          <p class="text-muted">
            Altitude
          </p>
          <p class="font-mono text-highlighted">
            {{ ownInfo.alt }} m (MSL: {{ ownInfo.altMsl }})
          </p>
        </div>
        <div>
          <p class="text-muted">
            Speed
          </p>
          <p class="font-mono text-highlighted">
            {{ ownInfo.speed }} m/s · V/S {{ ownInfo.vSpeed }}
          </p>
        </div>
        <div>
          <p class="text-muted">
            Heading / Sats
          </p>
          <p class="font-mono text-highlighted">
            {{ ownInfo.heading }}° / {{ ownInfo.sats }}
          </p>
        </div>
        <div>
          <p class="text-muted">
            GPS Fix
          </p>
          <p class="font-mono text-highlighted">
            {{ ownInfo.fix }} ({{ ownInfo.fixType }})
          </p>
        </div>
        <div>
          <p class="text-muted">
            Protocol / FW
          </p>
          <p class="truncate font-mono text-highlighted" :title="String(ownInfo.fw)">
            {{ ownInfo.protocol }} · {{ ownInfo.fw }}
          </p>
        </div>
        <div>
          <p class="text-muted">
            Uptime / TX
          </p>
          <p class="font-mono text-highlighted">
            {{ ownInfo.uptime }} · {{ ownInfo.txTotal }}
          </p>
        </div>
      </div>
    </div>

    <div
      v-if="selectedDrone"
      class="pointer-events-auto absolute bottom-7 left-3 z-[1001] w-[min(340px,calc(100vw-1.5rem))] rounded-lg border border-default bg-default/95 shadow-xl"
    >
      <div class="flex items-center justify-between gap-2 border-b border-default px-3 py-2">
        <div class="flex items-center gap-2">
          <UIcon name="i-lucide-radio" class="size-4 text-warning" />
          <p class="text-sm font-semibold text-highlighted">
            Nearby Drone
          </p>
        </div>
        <UButton
          color="neutral"
          variant="ghost"
          size="xs"
          icon="i-lucide-x"
          @click="selectedDrone = null"
        />
      </div>
      <div class="grid grid-cols-2 gap-2 px-3 py-2 text-xs">
        <div class="col-span-2">
          <p class="text-muted">
            UAS ID
          </p>
          <p class="break-all font-mono text-highlighted">
            {{ selectedDrone.uas_id ?? selectedDrone.uav_id ?? selectedDrone.serial ?? selectedDrone.id ?? '--' }}
          </p>
        </div>
        <div>
          <p class="text-muted">
            Operator
          </p>
          <p class="break-all font-mono text-highlighted">
            {{ selectedDrone.operator_id ?? selectedDrone.operator ?? '--' }}
          </p>
        </div>
        <div>
          <p class="text-muted">
            Registration
          </p>
          <p class="break-all font-mono text-highlighted">
            {{ selectedDrone.registration ?? '--' }}
          </p>
        </div>
        <div>
          <p class="text-muted">
            Position
          </p>
          <p class="font-mono text-highlighted">
            {{ Number((selectedDrone.lat as unknown) ?? (selectedDrone as Record<string, unknown>).latitude).toFixed(5) }}, {{ Number((selectedDrone.lng as unknown) ?? (selectedDrone.lon as unknown) ?? (selectedDrone as Record<string, unknown>).longitude).toFixed(5) }}
          </p>
        </div>
        <div>
          <p class="text-muted">
            Alt / Speed
          </p>
          <p class="font-mono text-highlighted">
            {{ selectedDrone.altitude ?? selectedDrone.alt ?? '--' }} m / {{ selectedDrone.speed ?? '--' }} m/s
          </p>
        </div>
        <div>
          <p class="text-muted">
            Heading
          </p>
          <p class="font-mono text-highlighted">
            {{ selectedDrone.heading ?? '--' }}°
          </p>
        </div>
        <div>
          <p class="text-muted">
            RSSI / Last seen
          </p>
          <p class="font-mono text-highlighted">
            {{ selectedDrone.rssi ?? '--' }} / {{ selectedDrone.last_seen ?? '--' }}
          </p>
        </div>
      </div>
    </div>
  </div>
</template>

<style>
[data-drone-map] .leaflet-container {
  width: 100%;
  height: 100%;
  font: inherit;
  background: #06090d;
}

[data-drone-map] .leaflet-tile-pane {
  filter: none;
}

[data-drone-map] .leaflet-attribution-flag {
  display: none !important;
}

.cd-map-nearby {
  width: 14px;
  height: 14px;
  border-radius: 9999px;
  background: radial-gradient(circle, #f59e0b, #d97706);
  border: 2px solid #fcd34d;
  box-shadow: 0 0 0 3px rgb(245 158 11 / 25%), 0 1px 6px rgb(0 0 0 / 60%);
  cursor: pointer;
}

[data-drone-map] .leaflet-popup-content-wrapper {
  border-radius: 0.375rem;
  border: 1px solid #1a242f;
  background: #0d1219;
  color: #e8ecf6;
}

[data-drone-map] .leaflet-popup-tip {
  background: #0d1219;
}

[data-drone-map] .leaflet-popup-content {
  font-family: 'JetBrains Mono', ui-monospace, monospace;
}

[data-drone-map] .leaflet-control-attribution {
  background: rgb(6 9 13 / 75%);
  color: #9aa3b5;
  font-size: 10px;
}

[data-drone-map] .leaflet-control-attribution a {
  color: #7dd3fc;
}

.cd-cardiv {
  background: transparent;
  border: none;
}

.cd-map-drone {
  position: relative;
  width: 26px;
  height: 26px;
  border-radius: 50%;
  background: radial-gradient(circle at 50% 30%, #93c5fd 0%, #2563eb 55%, #1e40af 100%);
  border: 2px solid #dbeafe;
  box-shadow: 0 0 0 4px rgb(37 99 235 / 28%), 0 4px 12px rgb(15 23 42 / 70%);
  transition: transform 0.3s ease;
}

.cd-map-drone::before {
  content: '';
  position: absolute;
  left: 50%;
  top: -14px;
  width: 2px;
  height: 10px;
  margin-left: -1px;
  background: linear-gradient(180deg, #bfdbfe 0%, #2563eb 100%);
  border-radius: 2px;
}

.cd-map-drone::after {
  content: '';
  position: absolute;
  left: 50%;
  top: -18px;
  width: 0;
  height: 0;
  margin-left: -5px;
  border-left: 5px solid transparent;
  border-right: 5px solid transparent;
  border-bottom: 10px solid #bfdbfe;
  filter: drop-shadow(0 -1px 2px rgb(37 99 235 / 40%));
}

.cd-map-home {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 28px;
  height: 28px;
  border-radius: 50%;
  background: radial-gradient(circle at 50% 30%, #86efac 0%, #22c55e 55%, #15803d 100%);
  color: #f0fdf4;
  border: 2px solid #dcfce7;
  box-shadow: 0 0 0 4px rgb(34 197 94 / 24%), 0 4px 12px rgb(15 23 42 / 65%);
}
</style>
`,T=`<script setup lang="ts">
import { formatTimeAgo } from '@vueuse/core'
import type { SystemNotificationSource, SystemNotificationType } from '~/composables/useNotifications'

const { isNotificationsSlideoverOpen } = useDashboard()
const { notifications, unreadCount, errorCount, warningCount, markAllRead, remove, clear } = useNotifications()

const notificationIcon = (type: SystemNotificationType) => ({
  error: 'i-lucide-circle-x',
  warning: 'i-lucide-triangle-alert',
  info: 'i-lucide-circle-check'
}[type])

const notificationColor = (type: SystemNotificationType) => ({
  error: 'text-error',
  warning: 'text-warning',
  info: 'text-success'
}[type])

const sourceLabel = (source: SystemNotificationSource) => ({
  app: 'App',
  firmware: 'Firmware',
  connection: 'Connection'
}[source])

const sourceIcon = (source: SystemNotificationSource) => ({
  app: 'i-lucide-layout-panel-left',
  firmware: 'i-lucide-cpu',
  connection: 'i-lucide-wifi'
}[source])
<\/script>

<template>
  <USlideover
    v-model:open="isNotificationsSlideoverOpen"
    title="Notifications"
  >
    <template #body>
      <div class="mb-2 space-y-2 border-b border-default px-1 pb-2">
        <div class="flex items-center justify-between gap-2">
          <p class="text-xs text-muted">
            {{ unreadCount ? \`\${unreadCount} unread\` : 'All caught up' }}
          </p>
          <div class="flex gap-1">
            <UButton
              color="neutral"
              variant="ghost"
              size="xs"
              icon="i-lucide-check-check"
              label="Mark all read"
              :disabled="!unreadCount"
              @click="markAllRead"
            />
            <UButton
              color="neutral"
              variant="ghost"
              size="xs"
              icon="i-lucide-trash"
              label="Clear"
              :disabled="!notifications.length"
              @click="clear"
            />
          </div>
        </div>

        <div v-if="notifications.length" class="flex flex-wrap items-center gap-1.5">
          <UBadge
            v-if="errorCount"
            color="error"
            variant="soft"
            size="sm"
            icon="i-lucide-circle-x"
          >
            {{ errorCount }} error{{ errorCount > 1 ? 's' : '' }}
          </UBadge>
          <UBadge
            v-if="warningCount"
            color="warning"
            variant="soft"
            size="sm"
            icon="i-lucide-triangle-alert"
          >
            {{ warningCount }} warning{{ warningCount > 1 ? 's' : '' }}
          </UBadge>
          <span class="text-xs text-dimmed">{{ notifications.length }} total</span>
        </div>
      </div>

      <UEmpty
        v-if="!notifications.length"
        icon="i-lucide-bell-off"
        title="No notifications"
        description="Warnings and errors from the app and the ESP32 console will appear here."
      />

      <div
        v-for="notification in notifications"
        :key="notification.id"
        class="flex items-start gap-3 border-b border-default px-1 py-4 last:border-b-0"
      >
        <UIcon :name="notificationIcon(notification.type)" :class="notificationColor(notification.type)" class="mt-0.5 size-5 shrink-0" />

        <div class="min-w-0 flex-1 text-sm">
          <p class="flex items-center justify-between gap-2">
            <span class="flex min-w-0 items-center gap-2 font-medium text-highlighted">
              <span class="truncate">{{ notification.title }}</span>
              <span v-if="notification.unread" class="size-1.5 shrink-0 rounded-full bg-primary" aria-label="Unread" />
              <UBadge
                v-if="notification.count > 1"
                color="neutral"
                variant="soft"
                size="sm"
              >
                ×{{ notification.count }}
              </UBadge>
            </span>

            <time
              :datetime="notification.date"
              class="shrink-0 text-muted text-xs"
              v-text="formatTimeAgo(new Date(notification.date))"
            />
          </p>

          <p class="text-dimmed">
            {{ notification.body }}
          </p>

          <p class="mt-1 flex items-center justify-between gap-2">
            <span class="flex items-center gap-1 text-[11px] text-muted">
              <UIcon :name="sourceIcon(notification.source)" class="size-3" />
              {{ sourceLabel(notification.source) }}
            </span>
            <UButton
              color="neutral"
              variant="ghost"
              size="xs"
              icon="i-lucide-x"
              aria-label="Dismiss notification"
              @click="remove(notification.id)"
            />
          </p>
        </div>
      </div>
    </template>
  </USlideover>
</template>
`,E=`<script setup lang="ts">
export type PageBadgeColor = 'error' | 'primary' | 'secondary' | 'success' | 'info' | 'warning' | 'neutral'

const props = defineProps<{
  title: string
  description?: string
  icon?: string
  eyebrow?: string
  badges?: { label: string, color?: PageBadgeColor }[]
  status?: { label: string, color?: PageBadgeColor }
  size?: 'sm' | 'md' | 'lg'
}>()

const slots = useSlots()

const sizeKey = computed(() => props.size ?? 'md')

const titleClass = computed(() => ({
  sm: 'text-2xl sm:text-3xl',
  md: 'text-3xl sm:text-4xl',
  lg: 'text-4xl sm:text-5xl lg:text-6xl'
}[sizeKey.value]))

const descriptionClass = computed(() => ({
  sm: 'text-sm leading-6 sm:text-[0.95rem]',
  md: 'text-base leading-7 sm:text-lg',
  lg: 'text-base leading-7 sm:text-lg'
}[sizeKey.value]))
<\/script>

<template>
  <section class="relative isolate -mx-4 overflow-hidden border-b border-default px-4 py-7 sm:-mx-6 sm:px-6 lg:-mx-10 lg:px-10 lg:py-9">
    <div aria-hidden="true" class="app-grid pointer-events-none absolute inset-0 -z-10 opacity-70" />
    <div
      aria-hidden="true"
      class="pointer-events-none absolute -top-24 left-0 -z-10 h-56 w-[36rem] max-w-full [background:radial-gradient(50%_100%_at_0%_0%,var(--app-glow),transparent_70%)]"
    />

    <div class="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between lg:gap-10">
      <div class="min-w-0 space-y-3">
        <div
          v-if="eyebrow || badges?.length"
          class="flex flex-wrap items-center gap-x-3 gap-y-1.5"
        >
          <span v-if="eyebrow" class="label-data">{{ eyebrow }}</span>
          <span v-if="eyebrow && badges?.length" aria-hidden="true" class="h-3 w-px bg-accented" />
          <UBadge
            v-for="badge in badges"
            :key="badge.label"
            :color="badge.color ?? 'neutral'"
            variant="soft"
            size="sm"
            :label="badge.label"
          />
        </div>

        <div class="flex flex-wrap items-center gap-x-3 gap-y-2">
          <UIcon v-if="icon" :name="icon" class="size-6 shrink-0 text-primary sm:size-7" />
          <h1 class="text-display text-highlighted" :class="titleClass">
            {{ title }}
          </h1>
          <UBadge
            v-if="status"
            :color="status.color ?? 'neutral'"
            variant="soft"
            :label="status.label"
          />
        </div>

        <p v-if="description" class="max-w-2xl text-muted" :class="descriptionClass">
          {{ description }}
        </p>

        <div v-if="slots.actions" class="flex flex-wrap gap-2 pt-1">
          <slot name="actions" />
        </div>
      </div>

      <div v-if="slots.right" class="w-full shrink-0 lg:w-auto lg:max-w-md">
        <slot name="right" />
      </div>
    </div>
  </section>
</template>
`,D=`<script setup lang="ts">
type Preset = {
  id: string
  name: string
  notes: string
  config: Record<string, unknown>
  createdAt: string
}

const PRESETS_KEY = 'omnirid:presets'

const { isEspConnected, canConfig, proxyFetch } = useEspConnection()
const { notifyInfo, notifyError } = useNotifications()
const toast = useToast()

const loadPresets = (): Preset[] => {
  if (!true) return []
  try {
    return JSON.parse(localStorage.getItem(PRESETS_KEY) ?? '[]') as Preset[]
  } catch {
    return []
  }
}

const presets = ref<Preset[]>(loadPresets())
const name = ref('')
const notes = ref('')
const capturedConfig = ref<Record<string, unknown> | null>(null)
const isCapturing = ref(false)
const applyingId = ref<string | null>(null)
const fileInput = ref<HTMLInputElement | null>(null)
const query = ref('')
const expandedId = ref<string | null>(null)

const persist = () => {
  if (true) localStorage.setItem(PRESETS_KEY, JSON.stringify(presets.value))
}

const filteredPresets = computed(() => {
  const q = query.value.trim().toLowerCase()
  if (!q) return presets.value
  return presets.value.filter(preset =>
    preset.name.toLowerCase().includes(q) || preset.notes.toLowerCase().includes(q)
  )
})

const fieldCount = (preset: Preset) => Object.keys(preset.config).length

const formatDate = (iso: string) => {
  const date = new Date(iso)
  return Number.isNaN(date.getTime()) ? 'unknown' : date.toLocaleString()
}

const togglePreview = (preset: Preset) => {
  expandedId.value = expandedId.value === preset.id ? null : preset.id
}

const captureFromDevice = async () => {
  if (!canConfig.value || isCapturing.value) return
  isCapturing.value = true
  try {
    const data = await proxyFetch<Record<string, unknown> | null>('api/config', { timeout: 5000 })
    capturedConfig.value = data && typeof data === 'object' ? data : null
    if (!capturedConfig.value) throw new Error('Empty device configuration')
    toast.add({
      title: 'Configuration captured',
      description: 'Fill in a name and save the preset.',
      icon: 'i-lucide-check',
      color: 'success'
    })
  } catch (error) {
    capturedConfig.value = null
    const message = error instanceof Error ? error.message : 'Could not read the device configuration.'
    toast.add({
      title: 'Capture failed',
      description: message,
      icon: 'i-lucide-circle-alert',
      color: 'error'
    })
    notifyError('Capture failed', message)
  } finally {
    isCapturing.value = false
  }
}

const savePreset = () => {
  const presetName = name.value.trim()
  if (!presetName || !capturedConfig.value) return
  presets.value.unshift({
    id: typeof crypto !== 'undefined' && 'randomUUID' in crypto ? crypto.randomUUID() : \`\${Date.now()}\`,
    name: presetName,
    notes: notes.value.trim(),
    config: capturedConfig.value,
    createdAt: new Date().toISOString()
  })
  persist()
  name.value = ''
  notes.value = ''
  capturedConfig.value = null
  toast.add({
    title: 'Preset saved',
    description: \`\${presetName} added to the local preset library.\`,
    icon: 'i-lucide-check',
    color: 'success'
  })
}

const applyPreset = async (preset: Preset) => {
  if (!canConfig.value || applyingId.value) return
  applyingId.value = preset.id
  try {
    await proxyFetch('api/config', { method: 'POST', body: preset.config, timeout: 8000 })
    toast.add({
      title: 'Preset applied',
      description: \`\${preset.name} was sent to the device.\`,
      icon: 'i-lucide-check',
      color: 'success'
    })
    notifyInfo('Preset applied', \`\${preset.name} was sent to the device.\`)
  } catch (error) {
    toast.add({
      title: 'Apply failed',
      description: error instanceof Error ? error.message : 'The device did not accept the preset.',
      icon: 'i-lucide-circle-alert',
      color: 'error'
    })
    notifyError('Preset apply failed', \`The device did not accept \${preset.name}.\`)
  } finally {
    applyingId.value = null
  }
}

const exportPreset = (preset: Preset) => {
  const blob = new Blob([JSON.stringify({ name: preset.name, notes: preset.notes, config: preset.config }, null, 2)], { type: 'application/json' })
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = \`omnirid-preset-\${preset.name.toLowerCase().replaceAll(/\\s+/g, '-')}.json\`
  link.click()
  URL.revokeObjectURL(url)
}

const removePreset = (preset: Preset) => {
  presets.value = presets.value.filter(item => item.id !== preset.id)
  if (expandedId.value === preset.id) expandedId.value = null
  persist()
}

const importPreset = async (event: Event) => {
  const input = event.target as HTMLInputElement
  const file = input.files?.[0]
  input.value = ''
  if (!file) return
  try {
    const parsed = JSON.parse(await file.text()) as Partial<Preset>
    const config = parsed.config && typeof parsed.config === 'object' ? parsed.config as Record<string, unknown> : null
    if (!config || !parsed.name) throw new Error('Not a valid OmniRID preset file')
    presets.value.unshift({
      id: typeof crypto !== 'undefined' && 'randomUUID' in crypto ? crypto.randomUUID() : \`\${Date.now()}\`,
      name: parsed.name,
      notes: parsed.notes ?? '',
      config,
      createdAt: new Date().toISOString()
    })
    persist()
    toast.add({
      title: 'Preset imported',
      description: \`\${parsed.name} imported into the local library.\`,
      icon: 'i-lucide-check',
      color: 'success'
    })
  } catch (error) {
    const message = error instanceof Error ? error.message : 'The selected file is not a valid OmniRID preset.'
    toast.add({
      title: 'Import failed',
      description: message,
      icon: 'i-lucide-circle-alert',
      color: 'error'
    })
    notifyError('Preset import failed', message)
  }
}
<\/script>

<template>
  <div class="grid gap-6 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)]">
    <!-- Capture & save -->
    <div class="space-y-4">
      <div class="overflow-hidden rounded-lg border border-default bg-elevated/40">
        <div class="flex items-start justify-between gap-3 border-b border-default px-4 py-3.5">
          <div class="min-w-0">
            <h3 class="flex items-center gap-2 text-sm font-semibold text-highlighted">
              <UIcon name="i-lucide-download" class="size-4 text-primary" />
              Capture from device
            </h3>
            <p class="mt-1 text-xs text-muted">
              Read the live settings from the ESP32 over <code class="font-mono">GET /api/config</code>.
            </p>
          </div>
          <UButton
            color="primary"
            variant="soft"
            icon="i-lucide-scan-line"
            class="shrink-0"
            :loading="isCapturing"
            :disabled="!canConfig"
            aria-label="Capture device configuration"
            @click="captureFromDevice"
          >
            <span class="hidden sm:inline">Capture</span>
          </UButton>
        </div>
        <div class="px-4 py-3">
          <div v-if="capturedConfig" class="flex items-center gap-2">
            <span class="size-1.5 shrink-0 rounded-full bg-success" aria-hidden="true" />
            <span class="font-mono text-xs text-highlighted">{{ Object.keys(capturedConfig).length }} fields</span>
            <span class="text-xs text-muted">ready to save</span>
          </div>
          <p v-else class="flex items-center gap-2 text-xs text-dimmed">
            <span class="size-1.5 shrink-0 rounded-full bg-accented" aria-hidden="true" />
            No configuration captured yet
          </p>
          <p v-if="!canConfig" class="mt-3 flex items-start gap-2 text-xs text-warning">
            <UIcon :name="isEspConnected ? 'i-lucide-usb' : 'i-lucide-wifi-off'" class="mt-0.5 size-4 shrink-0" />
            <span v-if="isEspConnected">Presets capture and apply device configuration, which is only available over WiFi.</span>
            <span v-else>ESP not connected — capture and apply are disabled until the device is reachable.</span>
          </p>
        </div>
      </div>

      <div class="space-y-3 rounded-lg border border-default bg-elevated/40 p-4">
        <h3 class="flex items-center gap-2 text-sm font-semibold text-highlighted">
          <UIcon name="i-lucide-save" class="size-4 text-primary" />
          Save preset
        </h3>
        <UInput v-model="name" placeholder="Preset name (e.g. Racing - EU)" aria-label="Preset name" />
        <UTextarea
          v-model="notes"
          placeholder="Notes (optional)"
          aria-label="Preset notes"
          :rows="3"
        />
        <UButton
          color="primary"
          icon="i-lucide-plus"
          label="Save preset"
          block
          :disabled="!name.trim() || !capturedConfig"
          @click="savePreset"
        />
      </div>

      <UButton
        color="neutral"
        variant="outline"
        icon="i-lucide-upload"
        label="Import preset file"
        block
        @click="fileInput?.click()"
      />
      <input
        ref="fileInput"
        type="file"
        accept="application/json,.json"
        class="hidden"
        aria-label="Import preset file"
        @change="importPreset"
      >
    </div>

    <!-- Library -->
    <div class="space-y-4">
      <div class="flex flex-wrap items-center justify-between gap-3">
        <h3 class="flex items-center gap-2 text-sm font-semibold text-highlighted">
          <UIcon name="i-lucide-library" class="size-4 text-primary" />
          Preset library
          <span class="rounded-sm bg-elevated px-1.5 py-0.5 font-mono text-[11px] font-normal text-muted">{{ presets.length }}</span>
        </h3>
        <UInput
          v-if="presets.length"
          v-model="query"
          icon="i-lucide-search"
          size="sm"
          placeholder="Filter presets…"
          aria-label="Filter presets"
          class="w-full sm:w-56"
        />
      </div>

      <UEmpty
        v-if="!presets.length"
        icon="i-lucide-library"
        title="No presets yet"
        description="Capture the current device configuration and save it here as a reusable preset."
      />

      <UEmpty
        v-else-if="!filteredPresets.length"
        icon="i-lucide-search-x"
        title="No matches"
        :description="\`No preset matches “\${query}”.\`"
      />

      <div v-else class="space-y-3">
        <article
          v-for="preset in filteredPresets"
          :key="preset.id"
          class="overflow-hidden rounded-lg border border-default bg-elevated/40"
        >
          <div class="flex items-start justify-between gap-3 p-4">
            <div class="min-w-0">
              <p class="truncate text-sm font-semibold text-highlighted">
                {{ preset.name }}
              </p>
              <p class="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 font-mono text-[11px] text-muted">
                <span>{{ fieldCount(preset) }} fields</span>
                <span aria-hidden="true" class="text-dimmed">·</span>
                <span>{{ formatDate(preset.createdAt) }}</span>
              </p>
            </div>
            <div class="flex shrink-0 items-center gap-1">
              <UButton
                color="primary"
                size="xs"
                icon="i-lucide-play"
                label="Apply"
                :loading="applyingId === preset.id"
                :disabled="!canConfig || !!applyingId"
                @click="applyPreset(preset)"
              />
              <UButton
                color="neutral"
                variant="ghost"
                size="xs"
                icon="i-lucide-download"
                aria-label="Export preset"
                @click="exportPreset(preset)"
              />
              <UButton
                color="neutral"
                variant="ghost"
                size="xs"
                icon="i-lucide-trash"
                aria-label="Delete preset"
                @click="removePreset(preset)"
              />
            </div>
          </div>

          <p v-if="preset.notes" class="border-t border-default px-4 py-2.5 text-xs leading-5 text-muted">
            {{ preset.notes }}
          </p>

          <button
            type="button"
            class="flex w-full items-center justify-between gap-2 border-t border-default px-4 py-2 text-left text-xs text-muted transition-colors hover:bg-elevated/60"
            :aria-expanded="expandedId === preset.id"
            @click="togglePreview(preset)"
          >
            <span class="flex items-center gap-1.5">
              <UIcon :name="expandedId === preset.id ? 'i-lucide-chevron-down' : 'i-lucide-chevron-right'" class="size-3.5" />
              Configuration
            </span>
            <span class="font-mono text-[11px] text-dimmed">{{ expandedId === preset.id ? 'hide' : 'preview' }}</span>
          </button>

          <div v-if="expandedId === preset.id" class="border-t border-default bg-default/60 p-3">
            <pre class="max-h-64 overflow-auto whitespace-pre-wrap font-mono text-[11px] leading-5 text-dimmed">{{ JSON.stringify(preset.config, null, 2) }}</pre>
          </div>
        </article>
      </div>
    </div>
  </div>
</template>
`,O=`<script setup lang="ts">
import { pageGroups } from '~/pages.config'

const props = defineProps<{ group: string }>()
const route = useRoute()
const { settings } = useAppSettings()

const tabItems = computed(() => {
  const group = pageGroups.find(item => item.id === props.group)
  return (group?.items ?? [])
    .filter(item => item.status !== 'wip' || settings.value.expertMode)
    .map(item => ({ label: item.label, icon: item.icon, to: item.to }))
})
<\/script>

<template>
  <nav
    v-if="tabItems.length > 1"
    class="flex flex-wrap items-center gap-1 rounded-lg border border-default bg-elevated/40 p-1"
    aria-label="Section navigation"
  >
    <NuxtLink
      v-for="tab in tabItems"
      :key="tab.to"
      :to="tab.to"
      class="flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-[13px] font-medium transition-colors"
      :class="route.path === tab.to
        ? 'bg-primary/15 text-primary'
        : 'text-muted hover:bg-elevated hover:text-highlighted'"
    >
      <UIcon :name="tab.icon" class="size-4 shrink-0" />
      <span class="whitespace-nowrap">{{ tab.label }}</span>
    </NuxtLink>
  </nav>
</template>
`,k=`<script setup lang="ts">
import { onBeforeUnmount, onMounted } from 'vue'
import { useIntervalFn } from '@vueuse/core'

type Sample = { recordedAt: string } & Record<string, string>

const { isEspConnected, proxyFetch } = useEspConnection()

const samples = ref<Sample[]>([])
const isRecording = ref(false)
const lastPollAt = ref<string | null>(null)
const lastError = ref<string | null>(null)

const csvEscape = (value: unknown) => {
  const text = value === null || value === undefined ? '' : String(value)
  return /[",\\n\\r]/.test(text) ? \`"\${text.replaceAll('"', '""')}"\` : text
}

const flatten = (value: unknown, prefix: string, out: Record<string, unknown>) => {
  if (Array.isArray(value)) {
    value.forEach((item, index) => flatten(item, \`\${prefix}[\${index}]\`, out))
  } else if (value !== null && typeof value === 'object') {
    for (const [key, item] of Object.entries(value as Record<string, unknown>)) {
      flatten(item, prefix ? \`\${prefix}_\${key}\` : key, out)
    }
  } else {
    out[prefix] = value
  }
}

const snapshot = async () => {
  if (!isEspConnected.value) return
  try {
    const data = await proxyFetch<Record<string, unknown> | null>('api/status', { timeout: 3000 })
    if (data && typeof data === 'object') {
      const flat: Record<string, unknown> = {}
      flatten(data, '', flat)
      samples.value.push({ recordedAt: new Date().toISOString(), ...Object.fromEntries(Object.entries(flat).map(([key, value]) => [key, String(value)])) })
      lastError.value = null
    }
  } catch (error) {
    lastError.value = error instanceof Error ? error.message : 'Status request failed'
    if (isRecording.value) stop()
  } finally {
    lastPollAt.value = new Date().toISOString()
  }
}

const { pause, resume } = useIntervalFn(snapshot, 2000)

const start = () => {
  if (!isEspConnected.value || isRecording.value) return
  isRecording.value = true
  snapshot()
  resume()
}

const stop = () => {
  isRecording.value = false
  pause()
}

watch(isEspConnected, (connected) => {
  if (!connected && isRecording.value) stop()
})

const columns = computed(() => {
  const set = new Set<string>()
  for (const sample of samples.value) for (const key of Object.keys(sample)) set.add(key)
  return [...set]
})

const downloadCsv = () => {
  if (!samples.value.length) return
  const header = columns.value.join(',')
  const rows = samples.value.map(sample => columns.value.map(key => sample[key] ?? '').map(csvEscape).join(','))
  const blob = new Blob([[header, ...rows].join('\\n')], { type: 'text/csv;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = \`omnirid-telemetry-\${new Date().toISOString().slice(0, 19).replaceAll(':', '-')}.csv\`
  link.click()
  URL.revokeObjectURL(url)
}

const clear = () => {
  samples.value = []
}

const lastSample = computed(() => samples.value[samples.value.length - 1])

onMounted(() => {
  if (isEspConnected.value) snapshot()
})

onBeforeUnmount(stop)
<\/script>

<template>
  <div class="space-y-3">
    <div class="flex flex-wrap items-center gap-2">
      <UButton
        color="primary"
        :icon="isRecording ? 'i-lucide-square' : 'i-lucide-play'"
        :label="isRecording ? 'Stop recording' : 'Start recording'"
        :disabled="!isEspConnected"
        @click="isRecording ? stop() : start()"
      />
      <UButton
        color="neutral"
        variant="soft"
        icon="i-lucide-download"
        label="Download CSV"
        :disabled="!samples.length"
        @click="downloadCsv"
      />
      <UButton
        color="neutral"
        variant="ghost"
        icon="i-lucide-trash"
        label="Clear"
        :disabled="!samples.length"
        @click="clear"
      />
      <p class="ml-auto text-xs text-muted">
        {{ samples.length }} sample{{ samples.length === 1 ? '' : 's' }}<template v-if="lastPollAt">
          · last poll {{ lastPollAt }}
        </template>
      </p>
    </div>

    <div v-if="!isEspConnected" class="flex items-center gap-2 rounded-lg border border-warning/30 bg-warning/5 px-3 py-2 text-sm text-warning">
      <UIcon name="i-lucide-wifi-off" class="size-4 shrink-0" />
      <span>ESP not connected — recording is disabled until the device is reachable.</span>
    </div>

    <p v-if="lastError" class="flex items-center gap-2 rounded-lg border border-error/30 bg-error/5 px-3 py-2 text-sm text-error">
      <UIcon name="i-lucide-circle-alert" class="size-4 shrink-0" />
      <span>Status request failed: {{ lastError }}</span>
    </p>

    <div class="overflow-hidden rounded-lg border border-default bg-elevated/40">
      <div class="flex items-center justify-between gap-2 border-b border-default px-3 py-2">
        <p class="text-xs uppercase tracking-[0.18em] text-muted">
          Latest sample
        </p>
        <span v-if="isRecording" class="flex items-center gap-1.5 text-xs text-error">
          <span class="size-2 animate-pulse rounded-full bg-error" />Recording
        </span>
        <span v-else class="text-xs text-muted">Stopped</span>
      </div>
      <dl v-if="lastSample" class="grid grid-cols-2 gap-x-6 gap-y-1 p-3 text-xs sm:grid-cols-3 lg:grid-cols-4">
        <template v-for="[key, value] in Object.entries(lastSample)" :key="key">
          <div class="flex justify-between gap-2 border-b border-default/60 py-1">
            <dt class="text-muted">
              {{ key }}
            </dt>
            <dd class="truncate font-mono text-highlighted" :title="value">
              {{ value }}
            </dd>
          </div>
        </template>
      </dl>
      <UEmpty
        v-else
        icon="i-lucide-table"
        title="No samples yet"
        description="Start recording to capture telemetry from /api/status."
        class="p-6"
      />
    </div>
  </div>
</template>
`,A=`<script setup lang="ts">
import { pageForRoute, pageStatusMeta } from '~/pages.config'
import { DEFAULTS, pageStatus as schemaPageStatus } from '~/config/device'
import type { DeviceConfig, Issue, PageId } from '~/config/device'

type FieldType = 'text' | 'number' | 'password' | 'select' | 'toggle' | 'textarea' | 'chips'

export type ConfigField = {
  name: string
  label: string
  type?: FieldType
  placeholder?: string
  description?: string
  disabled?: boolean
  maxlength?: number
  options?: { label: string, value: string }[]
  value?: string | number | boolean
  stepper?: boolean
  step?: number
}

export type ConfigSection = {
  title: string
  description?: string
  fields: ConfigField[]
}

export type ConfigDanger = {
  title?: string
  description: string
  link?: { label: string, to: string }
}

const props = defineProps<{
  title?: string
  description: string
  icon?: string
  status?: string
  sections: ConfigSection[]
  group?: string
  readonly?: boolean
  savable?: boolean
  load?: boolean
  validateConfig?: (cfg: DeviceConfig) => Issue[]
  mapPayload?: (state: Record<string, unknown>) => Record<string, unknown>
  applyLoaded?: (cfg: Record<string, unknown>, set: (key: string, value: unknown) => void) => void
  danger?: (state: Record<string, unknown>) => ConfigDanger[]
  headerActions?: { label: string, to: string }[]
}>()

const toast = useToast()
const { protocol, region, target } = useDeviceProfile()
const { notifyInfo, notifyWarning, notifyError } = useNotifications()
const { configActions } = useDashboard()

const route = useRoute()
const page = computed(() => pageForRoute(route.path))
const heroTitle = computed(() => props.title ?? page.value?.label ?? '')
const heroIcon = computed(() => props.icon ?? page.value?.icon)
const savable = computed(() => props.savable !== false && !props.readonly)
const heroId = computed(() => heroTitle.value.toLowerCase().replaceAll(' ', '-'))

const pageId = computed<PageId | undefined>(() => {
  const segment = route.path.split('/')[2]
  const map: Record<string, PageId | undefined> = {
    'nation': 'nation', 'identity': 'identity',
    'flight-controller': 'fc', 'hardware': 'hardware', 'system': 'system', 'security': 'system'
  }
  return segment ? map[segment] : undefined
})

const issues = ref<Issue[]>([])
const dangerItems = computed(() => props.danger ? props.danger({ ...state }) : [])
const schemaStatus = computed(() => {
  if (!props.validateConfig || !pageId.value || !issues.value.length) return undefined
  const status = schemaPageStatus(issues.value, pageId.value)
  if (status === 'invalid') return { label: 'Invalid config', color: 'error' as const }
  if (status === 'warning') return { label: 'Check config', color: 'warning' as const }
  return undefined
})

const heroStatus = computed(() => props.status
  ? { label: props.status }
  : schemaStatus.value
    ? schemaStatus.value
    : page.value
      ? { ...pageStatusMeta(page.value.status) }
      : undefined)

const isFactoryResetOpen = ref(false)
const restartDevice = () => {
  toast.add({
    title: 'Restart device',
    description: 'Restart action ready to be sent to the ESP.',
    icon: 'i-lucide-rotate-ccw',
    color: 'warning'
  })
}
const performFactoryReset = () => {
  isFactoryResetOpen.value = false
  toast.add({
    title: 'Factory reset',
    description: 'Reset action ready to be sent to the ESP.',
    icon: 'i-lucide-alert-triangle',
    color: 'error'
  })
}

const fieldsFor = (sections: ConfigSection[]) => sections.flatMap(section => section.fields)

const initialValue = (field: ConfigField): string | number | boolean => {
  if (field.name === 'protocol') return protocol.value
  if (field.name === 'region') return region.value
  if (field.name === 'target') return target.value
  return field.value ?? (field.type === 'toggle' ? false : '')
}

// Heterogeneous form-state bag: fields hold strings, numbers and booleans and
// feed component v-models expecting different concrete types, so \`any\` is intended.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const state = reactive<Record<string, any>>(
  Object.fromEntries(fieldsFor(props.sections).map(field => [field.name, initialValue(field)]))
)

watch(() => props.sections, (sections) => {
  const fields = fieldsFor(sections)
  const names = new Set(fields.map(field => field.name))
  for (const field of fields) {
    if (!(field.name in state)) state[field.name] = initialValue(field)
  }
  for (const key of Object.keys(state)) {
    if (!names.has(key)) Reflect.deleteProperty(state, key)
  }
}, { deep: true })

watch(() => state.protocol, (value) => {
  if (typeof value === 'string') protocol.value = value as typeof protocol.value
})

watch(() => state.region, (value) => {
  if (typeof value === 'string') region.value = value as typeof region.value
})

watch(() => state.target, (value) => {
  if (typeof value === 'string') target.value = value as typeof target.value
})

const errors = reactive<Record<string, string>>({})
const isSaving = ref(false)

const validateField = (field: ConfigField) => {
  if (props.readonly || field.disabled) {
    Reflect.deleteProperty(errors, field.name)
    return true
  }

  const value = state[field.name]
  const text = typeof value === 'string' ? value.trim() : value
  let message = ''

  if (field.type === 'number' && (text === '' || !Number.isFinite(Number(text)))) {
    message = 'Enter a valid number.'
  } else if (field.name === 'operator_id' && ['auto', 'eur', 'faa', 'can', 'aus'].includes(region.value) && !text) {
    message = 'Operator ID is required for the selected region.'
  } else if (['uas_id', 'operator_id', 'second_id'].includes(field.name) && text && !/^[A-Za-z0-9_.:/ -]{3,32}$/.test(String(text))) {
    message = 'Use 3-32 letters, numbers or . _ : / -.'
  } else if (field.name === 'self_id' && text && String(text).length > 23) {
    message = 'Self-ID must be 23 characters or fewer.'
  } else if (field.name === 'ssid' && (!text || String(text).length > 32)) {
    message = 'SSID must contain 1-32 characters.'
  } else if (field.name === 'password' && String(text).length > 0 && (String(text).length < 8 || String(text).length > 63)) {
    message = 'Password must be empty or 8-63 characters.'
  } else if (['latitude', 'op_lat'].includes(field.name) && (Number(text) < -90 || Number(text) > 90)) {
    message = 'Latitude must be between -90 and 90.'
  } else if (['longitude', 'op_lon'].includes(field.name) && (Number(text) < -180 || Number(text) > 180)) {
    message = 'Longitude must be between -180 and 180.'
  } else if (['channel', 'wifi_channel'].includes(field.name) && (Number(text) < 1 || Number(text) > 13 || !Number.isInteger(Number(text)))) {
    message = 'WiFi channel must be an integer from 1 to 13.'
  } else if (field.name.includes('rate') && (Number(text) < 0 || Number(text) > 5)) {
    message = 'Rate must be between 0 and 5 Hz.'
  } else if (field.name === 'startup_delay' && (Number(text) < 0 || Number(text) > 30000)) {
    message = 'Startup delay must be between 0 and 30000 ms.'
  } else if (field.name.endsWith('_gpio') || field.name.endsWith('_pin')) {
    if (!Number.isInteger(Number(text)) || Number(text) < -1 || Number(text) > 48) message = 'GPIO must be an integer from -1 to 48.'
  }

  if (message) errors[field.name] = message
  else Reflect.deleteProperty(errors, field.name)
  return !message
}

const validateCompatibility = () => {
  let valid = true

  for (const field of fieldsFor(props.sections)) valid = validateField(field) && valid

  if (state.tx_pin !== undefined && state.rx_pin !== undefined && state.tx_pin === state.rx_pin) {
    errors.tx_pin = 'TX and RX must use different GPIO pins.'
    errors.rx_pin = 'TX and RX must use different GPIO pins.'
    valid = false
  }

  if (state.can_rx !== undefined && state.can_tx !== undefined && ((state.can_rx === -1) !== (state.can_tx === -1))) {
    errors.can_rx = 'Configure both DroneCAN pins or disable both.'
    errors.can_tx = 'Configure both DroneCAN pins or disable both.'
    valid = false
  }

  if (state.mavlink_usb === true && !['auto', 'mavlink'].includes(protocol.value)) {
    errors.mavlink_usb = 'MAVLink USB requires MAVLink or Auto-detect protocol.'
    valid = false
  }

  return valid
}

const { isEspConnected, canConfig, lastError, proxyFetch } = useEspConnection()

const isDisabled = (field: ConfigField) => props.readonly || field.disabled

const buildPayload = () => {
  const payload: Record<string, unknown> = {}
  for (const field of fieldsFor(props.sections)) {
    const value = state[field.name]
    if (value !== undefined && value !== '') payload[field.name] = value
  }
  return props.mapPayload ? props.mapPayload({ ...state }) : payload
}

const toDeviceConfig = (): DeviceConfig => {
  const raw = props.mapPayload ? props.mapPayload({ ...state }) : { ...state }
  const out = { ...DEFAULTS } as DeviceConfig
  for (const key of Object.keys(DEFAULTS)) {
    const value = (raw as Record<string, unknown>)[key]
    if (value !== undefined && value !== '') (out as unknown as Record<string, unknown>)[key] = value
  }
  return out
}

const validateSchema = () => {
  issues.value = []
  if (!props.validateConfig) return
  const all = props.validateConfig(toDeviceConfig())
  issues.value = pageId.value ? all.filter(issue => issue.page === pageId.value) : all
  for (const issue of issues.value) {
    if (issue.severity === 'error') errors[issue.field] = issue.message
    else if (errors[issue.field]) Reflect.deleteProperty(errors, issue.field)
  }
}

const setValue = (key: string, value: unknown) => {
  state[key] = value
}

onMounted(async () => {
  if (!props.load) return
  if (canConfig.value) {
    try {
      const cfg = await proxyFetch<Record<string, unknown>>('api/config', { timeout: 4500 })
      if (props.applyLoaded) props.applyLoaded(cfg, setValue)
      else {
        for (const field of fieldsFor(props.sections)) {
          if (cfg[field.name] !== undefined) state[field.name] = cfg[field.name]
        }
      }
    } catch (error) {
      /* Device offline: the connection watcher already flags it. Only warn when
         the device is reachable but refused/errored on the config request. */
      if (isEspConnected.value) {
        const message = lastError.value ?? (error instanceof Error ? error.message : 'The device did not return its configuration.')
        toast.add({
          title: 'Configuration not loaded',
          description: message,
          icon: 'i-lucide-circle-alert',
          color: 'warning'
        })
        notifyWarning('Configuration not loaded', message)
      }
    }
  }
  validateSchema()
})

const fileInput = ref<HTMLInputElement | null>(null)

const exportConfig = () => {
  const payload = { ...buildPayload(), exportedAt: new Date().toISOString() }
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' })
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = \`omnirid-\${heroId.value}.json\`
  link.click()
  URL.revokeObjectURL(url)
  toast.add({
    title: 'Configuration exported',
    description: \`\${heroTitle.value} saved as omnirid-\${heroId.value}.json.\`,
    icon: 'i-lucide-check',
    color: 'success'
  })
}

const importConfig = async (event: Event) => {
  const input = event.target as HTMLInputElement
  const file = input.files?.[0]
  input.value = ''
  if (!file) return

  try {
    const parsed = JSON.parse(await file.text()) as Record<string, unknown>
    let applied = 0
    for (const field of fieldsFor(props.sections)) {
      if (parsed[field.name] !== undefined) {
        state[field.name] = parsed[field.name]
        applied += 1
      }
    }
    if (applied === 0) throw new Error('No matching fields')
    validateCompatibility()
    validateSchema()
    toast.add({
      title: 'Configuration imported',
      description: \`Applied \${applied} fields from \${file.name}.\`,
      icon: 'i-lucide-check',
      color: 'success'
    })
    notifyInfo('Configuration imported', \`Applied \${applied} fields from \${file.name}.\`)
  } catch (error) {
    const message = error instanceof Error ? error.message : 'The selected file is not a valid configuration.'
    toast.add({
      title: 'Import failed',
      description: message,
      icon: 'i-lucide-circle-alert',
      color: 'error'
    })
    notifyError('Configuration import failed', message)
  }
}

const handleConfigAction = (action: 'save' | 'export') => {
  if (action === 'save') save()
  else exportConfig()
}

onBeforeMount(() => {
  configActions.on(handleConfigAction)
})
onBeforeUnmount(() => {
  configActions.off(handleConfigAction)
})

const save = async () => {
  if (!canConfig.value) return
  if (isSaving.value) return
  const compatible = validateCompatibility()
  validateSchema()
  if (!compatible || issues.value.some(issue => issue.severity === 'error')) {
    toast.add({
      title: 'Check the configuration',
      description: 'Some values are invalid or incompatible with the selected profile.',
      icon: 'i-lucide-circle-alert',
      color: 'error'
    })
    notifyError('Configuration not saved', 'Some values are invalid or incompatible with the selected profile.')
    return
  }

  try {
    isSaving.value = true
    await proxyFetch('api/config', { method: 'POST', body: buildPayload() })
    toast.add({
      title: \`\${heroTitle.value} saved\`,
      description: 'Configuration sent to the ESP.',
      icon: 'i-lucide-check',
      color: 'success'
    })
    notifyInfo(\`\${heroTitle.value} saved\`, 'Configuration sent to the ESP.')
  } catch {
    toast.add({
      title: 'ESP unreachable',
      description: !isEspConnected.value
        ? 'The device is not connected. Set the ESP address from the header.'
        : lastError.value ?? 'The device did not accept the configuration.',
      icon: 'i-lucide-circle-alert',
      color: 'error'
    })
    notifyError('ESP unreachable', !isEspConnected.value
      ? 'The device is not connected. Set the ESP address from the header.'
      : lastError.value ?? 'The device did not accept the configuration.')
  } finally {
    isSaving.value = false
  }
}
<\/script>

<template>
  <UDashboardPanel :id="heroId" class="bg-default" :ui="{ root: 'pt-16' }">
    <template #body>
      <div class="mx-auto w-full max-w-[1400px] space-y-6 px-4 pb-16 sm:px-6 lg:px-10">
        <SectionTabs v-if="group" :group="group" class="mb-2" />
        <PageHero
          :title="heroTitle"
          :icon="heroIcon"
          :description="description"
          :status="heroStatus"
          size="sm"
        >
          <template v-if="props.headerActions?.length" #actions>
            <UButton
              v-for="action in props.headerActions"
              :key="action.label"
              :label="action.label"
              :to="action.to"
              color="neutral"
              variant="soft"
              icon="i-lucide-arrow-up-right"
              trailing
            />
          </template>
        </PageHero>

        <form class="space-y-5" @submit.prevent="save">
          <ContentSection
            v-for="section in sections"
            :key="section.title"
            :title="section.title"
            :description="section.description"
            heading="md"
          >
            <div class="grid gap-5 md:grid-cols-2">
              <template v-for="field in section.fields" :key="field.name">
                <div v-if="field.type === 'chips'" class="flex flex-wrap items-center gap-1.5">
                  <UBadge
                    v-for="chip in field.options ?? []"
                    :key="chip.label"
                    color="neutral"
                    variant="outline"
                    :label="chip.label"
                  />
                </div>
                <UFormField
                  v-else
                  :label="field.label"
                  :description="field.description"
                  :error="errors[field.name]"
                  :class="field.type === 'textarea' ? 'md:col-span-2' : ''"
                >
                  <USwitch
                    v-if="field.type === 'toggle'"
                    v-model="state[field.name]"
                    :disabled="isDisabled(field)"
                    @update:model-value="validateField(field)"
                  />
                  <USelect
                    v-else-if="field.type === 'select'"
                    v-model="state[field.name]"
                    :items="field.options ?? []"
                    value-key="value"
                    :disabled="isDisabled(field)"
                    class="w-full"
                    @update:model-value="validateField(field)"
                  />
                  <UTextarea
                    v-else-if="field.type === 'textarea'"
                    v-model="state[field.name]"
                    :placeholder="field.placeholder"
                    :rows="4"
                    :maxlength="field.maxlength"
                    :disabled="isDisabled(field)"
                    class="w-full"
                    @blur="validateField(field)"
                  />
                  <UInput
                    v-else-if="field.type === 'number' && field.stepper"
                    v-model="state[field.name]"
                    type="number"
                    :step="field.step ?? 1"
                    :disabled="isDisabled(field)"
                    class="w-full"
                    @blur="validateField(field)"
                  />
                  <UInput
                    v-else
                    v-model="state[field.name]"
                    :type="field.type ?? 'text'"
                    :placeholder="field.placeholder"
                    :maxlength="field.maxlength"
                    :disabled="isDisabled(field)"
                    class="w-full"
                    @blur="validateField(field)"
                  />
                </UFormField>
              </template>
            </div>
          </ContentSection>

          <div
            v-if="savable && !canConfig"
            class="flex items-center gap-2 rounded-lg border border-warning/30 bg-warning/5 px-3 py-2 text-sm text-warning"
          >
            <UIcon :name="isEspConnected ? 'i-lucide-usb' : 'i-lucide-wifi-off'" class="size-4 shrink-0" />
            <span v-if="isEspConnected">Configuration is only available over WiFi — you are connected via USB.</span>
            <span v-else>ESP not connected — actions are disabled until the device is reachable.</span>
          </div>

          <div class="space-y-3">
            <UAlert
              v-for="(entry, index) in dangerItems"
              :key="index"
              color="error"
              variant="soft"
              icon="i-lucide-triangle-alert"
              class="rounded-lg"
            >
              <template #title>
                {{ entry.title }}
              </template>
              <template #description>
                <span class="text-[13px] leading-5">{{ entry.description }}</span>
                <NuxtLink
                  v-if="entry.link"
                  :to="entry.link.to"
                  class="mt-1 inline-flex items-center gap-1 text-[13px] font-medium text-primary hover:underline"
                >
                  {{ entry.link.label }}
                  <UIcon name="i-lucide-arrow-up-right" class="size-3.5" />
                </NuxtLink>
              </template>
            </UAlert>
          </div>

          <UAlert
            v-if="issues.length"
            color="warning"
            icon="i-lucide-circle-alert"
            variant="soft"
            class="rounded-lg"
          >
            <template #title>
              Configuration issues ({{ issues.length }})
            </template>
            <template #description>
              <ul class="list-inside list-disc space-y-1">
                <li v-for="(issue, index) in issues" :key="index" class="text-[13px] leading-5">
                  {{ issue.message }}
                </li>
              </ul>
            </template>
          </UAlert>

          <div v-if="savable" class="flex flex-wrap items-center justify-end gap-2 border-t border-default pt-4">
            <template v-if="group === 'tx'">
              <UButton
                type="button"
                color="neutral"
                variant="soft"
                icon="i-lucide-rotate-ccw"
                label="Restart device"
                :disabled="!canConfig"
                @click="restartDevice"
              />
              <UButton
                type="button"
                color="error"
                variant="soft"
                icon="i-lucide-alert-triangle"
                label="Factory reset"
                :disabled="!canConfig"
                @click="isFactoryResetOpen = true"
              />
            </template>
            <UButton
              type="button"
              color="neutral"
              variant="ghost"
              icon="i-lucide-upload"
              label="Import"
              @click="fileInput?.click()"
            />
            <UButton
              type="button"
              color="neutral"
              variant="ghost"
              icon="i-lucide-download"
              label="Export"
              @click="exportConfig"
            />
            <UButton
              type="submit"
              color="primary"
              icon="i-lucide-save"
              label="Save configuration"
              :loading="isSaving"
              :disabled="!canConfig"
            />
            <input
              ref="fileInput"
              type="file"
              accept="application/json,.json"
              class="hidden"
              aria-label="Import configuration file"
              @change="importConfig"
            >
          </div>
        </form>

        <UModal v-model:open="isFactoryResetOpen" title="Factory reset">
          <template #body>
            <p class="text-sm text-muted">
              This erases the device configuration and restores factory defaults. The action cannot be undone.
            </p>
          </template>
          <template #footer>
            <div class="flex justify-end gap-2">
              <UButton
                color="neutral"
                variant="ghost"
                size="sm"
                label="Cancel"
                @click="isFactoryResetOpen = false"
              />
              <UButton
                color="error"
                size="sm"
                icon="i-lucide-alert-triangle"
                label="Reset device"
                @click="performFactoryReset"
              />
            </div>
          </template>
        </UModal>
      </div>
    </template>
  </UDashboardPanel>
</template>
`,j=`<script setup lang="ts">
defineProps<{ message: string, icon?: string }>()
<\/script>

<template>
  <div class="flex flex-col gap-4 rounded-lg border border-dashed border-default bg-elevated/40 p-5 sm:flex-row sm:items-center sm:p-6">
    <span class="flex size-12 shrink-0 items-center justify-center rounded-sm bg-primary/10 text-primary" aria-hidden="true">
      <UIcon :name="icon || 'i-lucide-construction'" class="size-5" />
    </span>
    <div class="min-w-0">
      <p class="label-data">
        Coming soon
      </p>
      <p class="mt-1.5 text-sm leading-6 text-muted">
        {{ message }}
      </p>
    </div>
  </div>
</template>
`,M=`<script setup lang="ts">
import type { GuideSection } from '~/config/guide'
import GuideCodeBlock from '~/components/docs/GuideCodeBlock.vue'
import GuideDataTable from '~/components/docs/GuideDataTable.vue'
import GuideFlow from '~/components/docs/GuideFlow.vue'

defineProps<{ section: GuideSection }>()
<\/script>

<template>
  <div class="space-y-4">
    <!-- Section intro -->
    <p v-if="section.intro" class="text-sm leading-6 text-muted">
      {{ section.intro }}
    </p>

    <template v-for="(block, i) in section.blocks" :key="i">
      <!-- Sub-heading -->
      <div v-if="block.type === 'h'" class="flex items-center gap-2 pt-4">
        <span class="size-1.5 shrink-0 rounded-full bg-primary" />
        <h4 class="text-base font-bold tracking-tight text-highlighted">
          {{ block.text }}
        </h4>
      </div>

      <!-- Paragraph -->
      <p v-else-if="block.type === 'p'" class="text-sm leading-6 text-muted" v-html="block.html" />

      <!-- Callout -->
      <UAlert
        v-else-if="block.type === 'callout'"
        :title="block.title"
        :color="block.tone === 'warning' ? 'warning' : 'info'"
        variant="soft"
        :icon="block.tone === 'warning' ? 'i-lucide-triangle-alert' : 'i-lucide-lightbulb'"
        class="rounded-lg"
      >
        <template #description>
          <span class="text-sm leading-6" v-html="block.html" />
        </template>
      </UAlert>

      <!-- Unordered list -->
      <ul v-else-if="block.type === 'ul'" class="space-y-2">
        <li v-for="(item, j) in block.items" :key="j" class="flex gap-2 text-sm leading-6 text-muted">
          <UIcon name="i-lucide-check" class="mt-0.5 size-4 shrink-0 text-primary" />
          <span v-html="item" />
        </li>
      </ul>

      <!-- Ordered list -->
      <ol v-else-if="block.type === 'ol'" class="space-y-2">
        <li
          v-for="(item, j) in block.items"
          :key="j"
          class="flex gap-3 text-sm leading-6 text-muted"
        >
          <span class="mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-primary/10 text-[10px] font-semibold text-primary ring-1 ring-primary/20">
            {{ j + 1 }}
          </span>
          <span class="min-w-0" v-html="item" />
        </li>
      </ol>

      <!-- Code block -->
      <GuideCodeBlock v-else-if="block.type === 'code'" :code="block.code" />

      <!-- Single table -->
      <GuideDataTable
        v-else-if="block.type === 'table'"
        :cols="block.cols"
        :rows="block.rows"
        :caption="block.caption"
      />

      <!-- Grouped tables (NVS key layout) -->
      <div v-else-if="block.type === 'tables'" class="space-y-4">
        <template v-for="(group, gi) in block.groups" :key="gi">
          <GuideDataTable :cols="['NVS Key', 'Type', 'Parameter']" :rows="group.rows" :title="group.title" />
        </template>
      </div>

      <!-- Flow diagram -->
      <GuideFlow v-else-if="block.type === 'flow'" :flow="block.flow" />
    </template>
  </div>
</template>
`,N=`<script setup lang="ts">
const props = defineProps<{
  code: string
  label?: string
}>()

const copied = ref(false)
async function copyCode() {
  try {
    await navigator.clipboard.writeText(props.code)
    copied.value = true
    setTimeout(() => {
      copied.value = false
    }, 1600)
  } catch {
    const ta = document.createElement('textarea')
    ta.value = props.code
    ta.style.position = 'fixed'
    ta.style.opacity = '0'
    document.body.appendChild(ta)
    ta.select()
    try {
      document.execCommand('copy')
    } catch { /* noop */ }
    document.body.removeChild(ta)
    copied.value = true
    setTimeout(() => {
      copied.value = false
    }, 1600)
  }
}
<\/script>

<template>
  <div class="overflow-hidden rounded-lg border border-default bg-muted">
    <div class="flex items-center justify-between gap-3 border-b border-default bg-elevated/40 px-3 py-2">
      <span class="flex min-w-0 items-center gap-2">
        <span class="flex shrink-0 gap-1.5">
          <span class="size-2.5 rounded-full bg-red-400/70" />
          <span class="size-2.5 rounded-full bg-yellow-400/70" />
          <span class="size-2.5 rounded-full bg-green-400/70" />
        </span>
        <UBadge
          color="neutral"
          variant="subtle"
          size="xs"
          class="truncate"
        >
          <UIcon name="i-lucide-file-code-2" class="size-3" />
          {{ label ?? 'Code' }}
        </UBadge>
      </span>
      <UButton
        size="xs"
        color="neutral"
        variant="ghost"
        :icon="copied ? 'i-lucide-check' : 'i-lucide-copy'"
        :label="copied ? 'Copied' : 'Copy'"
        class="shrink-0"
        @click="copyCode"
      />
    </div>
    <pre class="overflow-x-auto p-4 text-xs leading-6 text-highlighted"><code class="font-mono">{{ code }}</code></pre>
  </div>
</template>
`,P=`<script setup lang="ts">
import { h } from 'vue'
import type { TableColumn } from '@nuxt/ui'

const props = defineProps<{
  cols: string[]
  rows: string[][]
  caption?: string
  title?: string
}>()

const columns = computed<TableColumn<Record<string, string>>[]>(() =>
  props.cols.map((header, i) => ({
    accessorKey: \`c\${i}\`,
    header,
    cell: ({ getValue }: { getValue: () => unknown }) =>
      h('span', { innerHTML: String(getValue() ?? ''), class: i === 0 ? 'font-medium text-highlighted' : undefined })
  }))
)

const data = computed(() =>
  props.rows.map(cells => Object.fromEntries(cells.map((c, i) => [\`c\${i}\`, c])))
)
<\/script>

<template>
  <UCard v-if="rows.length" class="overflow-hidden rounded-lg" :ui="{ root: 'shadow-none border-default', body: 'p-0' }">
    <template v-if="title || caption" #header>
      <div class="flex flex-wrap items-center justify-between gap-2 px-1 py-0.5">
        <div class="flex min-w-0 items-center gap-2">
          <UIcon name="i-lucide-table-2" class="size-4 shrink-0 text-primary" />
          <span class="truncate text-xs font-semibold uppercase tracking-[0.16em] text-muted">{{ title || caption }}</span>
        </div>
        <UBadge
          color="neutral"
          variant="soft"
          size="sm"
          :label="\`\${rows.length} rows\`"
        />
      </div>
    </template>
    <div class="hidden sm:block">
      <UTable
        :columns="columns"
        :data="data"
        :ui="{
          base: 'text-sm',
          thead: 'bg-elevated/40',
          tbody: 'divide-y divide-default',
          th: 'px-4 py-3 text-xs font-semibold uppercase tracking-wider text-muted',
          td: 'align-top p-3.5 text-sm text-muted',
          tr: 'transition-colors hover:bg-elevated/40'
        }"
      />
    </div>
    <div class="divide-y divide-default sm:hidden">
      <dl v-for="(row, ri) in rows" :key="ri" class="px-4 py-3">
        <template v-for="(cell, ci) in row" :key="ci">
          <div class="flex items-baseline gap-3 py-0.5">
            <dt class="w-1/3 shrink-0 text-[11px] font-semibold uppercase tracking-wider text-muted">
              {{ cols[ci] || \`Field \${ci + 1}\` }}
            </dt>
            <dd class="min-w-0 flex-1 break-words text-sm" :class="ci === 0 ? 'font-medium text-highlighted' : 'text-muted'" v-html="cell" />
          </div>
        </template>
      </dl>
    </div>
  </UCard>
</template>
`,F=`<script setup lang="ts">
import type { GuideFlow } from '~/config/guide'

defineProps<{ flow: GuideFlow }>()

const stepBadgeColors = ['primary', 'info', 'success', 'warning', 'error'] as const

const packBadgeColor = (index: number) => stepBadgeColors[index % stepBadgeColors.length]
<\/script>

<template>
  <!-- Linear: OTA flow -->
  <div
    v-if="flow.kind === 'linear'"
    class="rounded-lg border border-default bg-elevated/20 p-4 sm:p-5"
  >
    <div class="mb-3 flex items-center gap-2">
      <span class="flex size-6 items-center justify-center rounded-lg bg-primary/10 text-primary ring-1 ring-primary/20">
        <UIcon name="i-lucide-workflow" class="size-3.5" />
      </span>
      <p class="text-[10px] font-semibold uppercase tracking-[0.22em] text-muted">
        Flow
      </p>
      <UBadge
        color="primary"
        variant="soft"
        size="sm"
        :label="\`\${flow.nodes.length} steps\`"
      />
    </div>

    <div class="flex flex-wrap items-center gap-2">
      <template v-for="(node, i) in flow.nodes" :key="i">
        <div class="flex items-center gap-2">
          <div class="group/step max-w-56 rounded-lg border border-default bg-elevated/40 p-3 transition hover:border-primary/30">
            <div class="flex items-center gap-2">
              <span class="flex size-5 shrink-0 items-center justify-center rounded-full bg-primary/10 text-[10px] font-bold text-primary ring-1 ring-primary/20">{{ i + 1 }}</span>
              <p class="truncate text-xs font-bold text-highlighted">
                {{ node.label }}
              </p>
            </div>
            <p v-if="node.sub" class="mt-1.5 truncate text-[10px] leading-4 text-muted">
              {{ node.sub }}
            </p>
          </div>
          <span v-if="i < flow.nodes.length - 1" class="flex size-6 shrink-0 items-center justify-center rounded-full bg-elevated/60 ring-1 ring-default">
            <UIcon name="i-lucide-arrow-right" class="size-3.5 text-primary" />
          </span>
        </div>
      </template>
    </div>

    <UAlert
      v-if="flow.failure"
      color="warning"
      variant="soft"
      icon="i-lucide-rotate-ccw"
      class="mt-3 rounded-lg"
    >
      <template #description>
        <span class="text-xs"><span class="font-semibold">Failure → {{ flow.failure.to }}</span> — {{ flow.failure.note }}</span>
      </template>
    </UAlert>

    <p v-if="flow.caption" class="mt-3 text-[11px] leading-5 text-muted">
      {{ flow.caption }}
    </p>
  </div>

  <!-- Guard: protocol auto-detection -->
  <div
    v-else-if="flow.kind === 'guard'"
    class="rounded-lg border border-default bg-elevated/20 p-4 sm:p-5"
  >
    <div class="mb-3 flex items-center gap-2">
      <span class="flex size-6 items-center justify-center rounded-lg bg-primary/10 text-primary ring-1 ring-primary/20">
        <UIcon name="i-lucide-git-branch" class="size-3.5" />
      </span>
      <p class="text-[10px] font-semibold uppercase tracking-[0.22em] text-muted">
        Detection
      </p>
    </div>

    <UBadge
      color="primary"
      variant="soft"
      size="sm"
      icon="i-lucide-play"
      :label="flow.entry"
    />

    <div class="relative ms-1 mt-3 space-y-2.5 border-s-2 border-dashed border-default ps-4">
      <div v-for="(check, i) in flow.checks" :key="check.label" class="flex flex-wrap items-center gap-2">
        <div class="flex min-w-0 flex-1 items-center gap-2.5 rounded-lg border border-default bg-elevated/40 px-3 py-2.5 transition hover:border-amber-500/30">
          <span class="flex size-5 shrink-0 items-center justify-center rounded-full bg-amber-500/10 text-[10px] font-bold text-amber-500 ring-1 ring-amber-500/25">{{ i + 1 }}</span>
          <span class="min-w-0 text-xs font-medium text-highlighted" v-html="check.label" />
        </div>
        <UIcon name="i-lucide-arrow-right" class="size-4 shrink-0 text-muted" />
        <UBadge color="success" variant="soft" :label="\`Yes · \${check.ok}\`" />
        <UBadge
          v-if="i < flow.checks.length - 1"
          color="error"
          variant="outline"
          label="No"
        />
      </div>
    </div>

    <div class="mt-3 flex flex-wrap items-center gap-2">
      <UBadge
        color="neutral"
        variant="soft"
        icon="i-lucide-corner-down-left"
        :label="flow.fallback"
      />
      <UIcon name="i-lucide-arrow-right" class="size-4 text-muted" />
      <UBadge
        color="neutral"
        variant="outline"
        icon="i-lucide-loader"
        label="Main loop"
      />
    </div>

    <p
      v-if="flow.noData"
      class="mt-3 rounded-lg bg-default/70 px-3 py-2.5 text-[11px] leading-5 text-muted"
    >
      <span class="font-semibold text-highlighted">When no data arrives:</span> {{ flow.noData }}
    </p>
    <p v-if="flow.caption" class="mt-3 text-[11px] leading-5 text-muted">
      {{ flow.caption }}
    </p>
  </div>

  <!-- Pack: ODID message pack -->
  <div
    v-else-if="flow.kind === 'pack'"
    class="rounded-lg border border-default bg-elevated/20 p-4 sm:p-5"
  >
    <div class="mb-3 flex flex-wrap items-center justify-between gap-2">
      <div class="flex items-center gap-2.5">
        <span class="flex size-6 items-center justify-center rounded-lg bg-primary/10 text-primary ring-1 ring-primary/20">
          <UIcon name="i-lucide-package" class="size-3.5" />
        </span>
        <div>
          <p class="text-xs font-bold text-highlighted">
            ASTM F3411-22a Message Pack
          </p>
          <p class="text-[10px] text-muted">
            Single transmission
          </p>
        </div>
      </div>
      <UBadge
        color="primary"
        variant="soft"
        size="sm"
        :label="\`\${flow.messages.length} messages\`"
      />
    </div>

    <div class="grid gap-2 md:grid-cols-3">
      <div
        v-for="(msg, i) in flow.messages"
        :key="msg.id"
        class="rounded-lg border border-default bg-elevated/40 p-3 transition hover:border-primary/30"
      >
        <div class="flex items-center gap-2">
          <UBadge
            :color="packBadgeColor(i)"
            variant="soft"
            size="xs"
            :label="msg.id"
          />
          <span class="truncate text-xs font-semibold text-highlighted">{{ msg.label }}</span>
        </div>
        <p class="mt-1.5 text-[10px] leading-4 text-muted">
          {{ msg.lines }}
        </p>
      </div>
    </div>

    <div class="my-2.5 flex items-center gap-2">
      <UIcon name="i-lucide-arrow-down" class="size-4 text-primary" />
      <UBadge
        color="neutral"
        variant="outline"
        size="xs"
        label="Transport layer"
      />
    </div>

    <div class="grid gap-2 md:grid-cols-2">
      <div
        v-for="ts in flow.transports"
        :key="ts.name"
        class="flex items-start gap-2.5 rounded-lg border border-default bg-elevated/40 p-3 transition hover:border-primary/30"
      >
        <span class="flex size-7 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary ring-1 ring-primary/20">
          <UIcon name="i-lucide-wifi" class="size-3.5" />
        </span>
        <div class="min-w-0">
          <p class="text-xs font-semibold text-highlighted">
            {{ ts.name }}
          </p>
          <p class="mt-1 text-[10px] leading-4 text-muted">
            {{ ts.lines }}
          </p>
        </div>
      </div>
    </div>

    <p v-if="flow.caption" class="mt-3 text-[11px] leading-5 text-muted">
      {{ flow.caption }}
    </p>
  </div>
</template>
`,I=Object.assign({"../pages/dashboard.vue":e,"../pages/firmware.vue":t,"../pages/guide.vue":n,"../pages/index.vue":r,"../pages/rx/console.vue":i,"../pages/rx/hardware.vue":a,"../pages/rx/logging.vue":o,"../pages/rx/memory.vue":s,"../pages/rx/receiver.vue":c,"../pages/rx/security.vue":l,"../pages/tx/console.vue":u,"../pages/tx/flight-controller.vue":d,"../pages/tx/hardware.vue":f,"../pages/tx/identity.vue":p,"../pages/tx/logging.vue":m,"../pages/tx/memory.vue":h,"../pages/tx/nation-standard-transmission.vue":g,"../pages/tx/presets.vue":_,"../pages/tx/security.vue":v}),L=Object.assign({"../components/AppSettingsPanel.vue":y,"../components/AppSettingsPopover.vue":b,"../components/AppSettingsSlideover.vue":x,"../components/ConsoleTerminal.vue":S,"../components/ContentSection.vue":C,"../components/DroneMap.vue":w,"../components/NotificationsSlideover.vue":T,"../components/PageHero.vue":E,"../components/PresetManager.vue":D,"../components/SectionTabs.vue":O,"../components/TelemetryRecorder.vue":k,"../components/device/ConfigPage.vue":A,"../components/device/ConfigPlaceholder.vue":j,"../components/docs/GuideBlocks.vue":M,"../components/docs/GuideCodeBlock.vue":N,"../components/docs/GuideDataTable.vue":P,"../components/docs/GuideFlow.vue":F});export{L as componentSources,I as pageSources};